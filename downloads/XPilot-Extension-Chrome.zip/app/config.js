window.XPILOT_CONFIG = {
  "apiBase": "https://licensing-api-five.vercel.app",
  "xOrigin": "https://x.com",
  "hostPermissions": [
    "https://x.com/*",
    "https://twitter.com/*",
    "https://licensing-api-five.vercel.app/*"
  ],
  "defaultSelectors": {
    "TWEET_ARTICLE": [
      "article[data-testid=\"tweet\"]",
      "article[role=\"article\"]"
    ],
    "TWEET_TEXT": [
      "[data-testid=\"tweetText\"]",
      "div[lang]"
    ],
    "TWEET_AUTHOR": [
      "[data-testid=\"User-Name\"]"
    ],
    "REPLY_TEXTBOX": [
      "[data-testid=\"tweetTextarea_0\"]",
      "div[role=\"textbox\"][data-testid^=\"tweetTextarea\"]"
    ],
    "INLINE_REPLY_TEXTBOX": [
      "[data-testid=\"tweetTextarea_0\"]:not([role=\"dialog\"] *)",
      "div[role=\"textbox\"][data-testid^=\"tweetTextarea\"]:not([role=\"dialog\"] *)"
    ],
    "REPLY_BUTTON": [
      "[data-testid=\"reply\"]"
    ],
    "SUBMIT_BUTTON": [
      "[data-testid=\"tweetButtonInline\"]",
      "[data-testid=\"tweetButton\"]"
    ],
    "INLINE_SUBMIT_BUTTON": [
      "[data-testid=\"tweetButtonInline\"]:not([role=\"dialog\"] *)",
      "[data-testid=\"tweetButton\"]:not([role=\"dialog\"] *)"
    ],
    "POST_UNAVAILABLE": [
      "[data-testid=\"error-detail\"]"
    ],
    "TOAST": [
      "[data-testid=\"toast\"]",
      "div[role=\"alert\"]"
    ],
    "LOGGED_IN_MARKERS": [
      "[data-testid=\"SideNav_AccountSwitcher_Button\"]",
      "[data-testid=\"AppTabBar_Profile_Link\"]",
      "[data-testid=\"tweetTextarea_0\"]"
    ],
    "LOGGED_OUT_MARKERS": [
      "a[href*=\"/i/flow/login\"]",
      "a[href*=\"onboarding/web?mode=login\"]",
      "a[href*=\"mode=signup\"]",
      "[data-testid=\"loginButton\"]",
      "a[href=\"/login\"]"
    ],
    "LOGGED_OUT_ARTICLE": [
      "article[data-tweet-id]",
      "article[itemtype*=\"SocialMediaPosting\"]"
    ],
    "LIKE_BUTTON": [
      "article[data-testid=\"tweet\"] [data-testid=\"like\"]",
      "article[role=\"article\"] [data-testid=\"like\"]",
      "[data-testid=\"like\"]"
    ],
    "UNLIKE_BUTTON": [
      "article[data-testid=\"tweet\"] [data-testid=\"unlike\"]",
      "article[role=\"article\"] [data-testid=\"unlike\"]",
      "[data-testid=\"unlike\"]"
    ],
    "ARTICLE_BODY": [
      "[data-testid=\"twitterArticleRichTextView\"]",
      "[data-testid=\"twitterArticleReadView\"]",
      "[data-testid=\"longformRichTextComponent\"]",
      "div[data-contents=\"true\"]"
    ],
    "ARTICLE_TITLE": [
      "[data-testid=\"twitter-article-title\"]",
      "[data-testid=\"articleTitle\"]"
    ],
    "ARTICLE_LINK": [
      "a[href*=\"/i/article/\"]",
      "a[href*=\"/article/\"]"
    ],
    "ACCOUNT_RESTRICTED_PHRASES": [
      "your account is suspended",
      "permanently in read-only mode",
      "your account is temporarily restricted",
      "you can't post, repost, or like",
      "you can\u2019t post, repost, or like"
    ],
    "ARTICLE_RESTRICTED_PHRASES": [
      "these posts are protected",
      "this article is only available",
      "only available to subscribers",
      "subscribe to read",
      "subscribe to unlock",
      "age-restricted",
      "you're unable to view this",
      "you\u2019re unable to view this"
    ]
  },
  "duplicatePhrases": [
    "already said that",
    "duplicate",
    "status is a duplicate"
  ],
  "rateLimitPhrases": [
    "over the daily limit",
    "daily limit",
    "limit reached",
    "rate limit",
    "too many requests",
    "you have exceeded",
    "unable to perform this action",
    "caught in a filter",
    "temporarily restricted",
    "temporarily locked",
    "slow down"
  ],
  "minArticleChars": 200,
  "maxPostCharsForAi": 3500,
  "actionTimeoutMs": 15000,
  "navigationTimeoutMs": 35000,
  "minSecondsBetweenPosts": 4.0,
  "maxSecondsBetweenPosts": 10.0,
  "prePostPauseMs": 3000,
  "ownReplyWaitMs": 2500,
  "postBreakSeconds": 60,
  "returnFocusAfterMs": 6000,
  "aiTimeoutMs": 30000,
  "aiMaxRetries": 2,
  "aiBackoffMs": 1000,
  "offlineGraceDays": 7,
  "test": false,
  "forceTabMode": false
};
