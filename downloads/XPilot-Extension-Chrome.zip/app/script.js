/**
 * XPilot — Frontend Application Logic
 * ------------------------------------------------------------------
 * Vanilla ES6, no frameworks, no external libraries.
 *
 * Everything is wrapped in a single IIFE so nothing leaks onto
 * `window` — modules below communicate through the shared `state`
 * object and their public return values only.
 *
 * Pilot rows are state-driven: each row holds its link, the content read
 * from X, a generation status and a publishing status, and `renderRow()`
 * derives every visible detail from that. Recovery features (regenerate
 * failed replies, repost failed comments) are just filters over the same
 * state, so they can never touch a row that already succeeded.
 * ------------------------------------------------------------------ */
(() => {
  'use strict';

  /* ==========================================================
     STATE
  ========================================================== */
  const state = {
    selectedStyle: 'professional',
    likesEnabled: false, // when on, posting a reply also likes the post
    busy: null, // null | 'generating' | 'posting' — one run at a time
    license: null, // last /license/status payload
    usage: null, // last /license/usage payload (credits)
    prefs: { theme: 'dark', language: 'en-US', notifications: true, help_seen: false },
  };

  /* ==========================================================
     SMALL UTILITIES
  ========================================================== */
  function icon(name, cls = '') {
    return `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  }

  function escapeHtml(text) {
    return String(text ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function plural(n, one, many = `${one}s`) {
    return `${n} ${n === 1 ? one : many}`;
  }

  function capitalize(text) {
    return text ? text.charAt(0).toUpperCase() + text.slice(1) : '';
  }

  function formatDate(iso) {
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? String(iso) : d.toLocaleDateString();
  }

  function compactNumber(n) {
    const value = Number(n) || 0;
    if (value < 10000) return value.toLocaleString();
    if (value < 1e6) return `${(value / 1e3).toFixed(value < 1e5 ? 1 : 0).replace(/\.0$/, '')}K`;
    return `${(value / 1e6).toFixed(1).replace(/\.0$/, '')}M`;
  }

  // Clipboard with a fallback: the async API can be refused inside WebView2.
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      const area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      let ok = false;
      try {
        ok = document.execCommand('copy');
      } catch (_err) {
        ok = false;
      }
      area.remove();
      return ok;
    }
  }

  // Shared disable + inline-spinner treatment for a button.
  function setButtonLoading(btn, loadingLabel) {
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="btn-inline-spinner"></span><span>${escapeHtml(loadingLabel)}</span>`;
    return () => {
      btn.disabled = false;
      btn.innerHTML = originalHTML;
    };
  }

  /* ==========================================================
     X LINKS
     Posts (…/status/<id>) and X Articles (…/i/article/<id>).
  ========================================================== */
  const LINK_PATTERN =
    /https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\/(?:[A-Za-z0-9_]{1,15}\/status\/\d+|(?:i|[A-Za-z0-9_]{1,15})\/article\/\d+)/gi;
  const STATUS_RE = /^https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\/[A-Za-z0-9_]{1,15}\/status\/\d+/i;
  const ARTICLE_RE = /^https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\/(?:i|[A-Za-z0-9_]{1,15})\/article\/\d+/i;

  function extractLinks(text) {
    return (String(text || '').match(LINK_PATTERN) || []);
  }

  function classifyLink(url) {
    if (STATUS_RE.test(url)) return 'post';
    if (ARTICLE_RE.test(url)) return 'article';
    return null;
  }

  // "https://x.com/user/status/123?s=20" -> "https://x.com/user/status/123".
  function normalizeLink(raw) {
    const value = String(raw || '').trim();
    const found = extractLinks(value);
    return found.length === 1 ? found[0] : value;
  }

  function displayLink(url) {
    return url.replace(/^https?:\/\/(www\.|mobile\.)?/i, '');
  }

  /* ==========================================================
     API
  ========================================================== */
  // The desktop app serves this page from the backend itself, so the API is
  // always on the page's own origin. The fixed address is only for opening
  // the file directly (file://) or via VS Code Live Server during development.
  const DEV_BACKEND = 'http://127.0.0.1:4820';
  const servedByBackend =
    window.location.protocol.startsWith('http') && window.location.port !== '5500';
  const API_BASE = `${servedByBackend ? window.location.origin : DEV_BACKEND}/api`;

  async function apiRequest(path, options = {}) {
    // Inside the XPilot browser extension the same interface runs without
    // the local backend: its bridge answers the identical API in-browser.
    if (window.XPilotBridge) {
      try {
        return await window.XPilotBridge.request(path, options);
      } catch (error) {
        if (error.code === 'license_required') LicenseController.refresh();
        throw error;
      }
    }

    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      });
    } catch (err) {
      const error = new Error(
        'Could not reach the XPilot backend. It may have stopped — restart XPilot and try again.'
      );
      error.code = 'network_error';
      error.cause = err;
      throw error;
    }

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || data.error || `Request failed (${response.status})`);
      // Keep the backend's machine-readable code on the Error: callers use it
      // to tell "X is throttling this account" from an ordinary failure.
      error.code = data.error || null;
      error.status = response.status;
      error.details = data.details || null;
      // The license was deactivated or expired underneath the UI: re-gate.
      if (error.code === 'license_required') LicenseController.refresh();
      throw error;
    }
    return data;
  }

  const post = (path, body) => apiRequest(path, { method: 'POST', body: JSON.stringify(body || {}) });

  const API = {
    // Is the XPilot browser signed in to X? `navigate` true opens X (first
    // check); false just inspects the current page (polling while logging in).
    async checkLogin(navigate = true) {
      const data = await post('/browser/check-login', { navigate });
      return Boolean(data.logged_in);
    },
    // Phase 1 — open the post / X Article and extract its content.
    readPost(link) {
      return post('/read-post', { url: link });
    },
    // Phase 2 — generate a reply from already-extracted content.
    async generateFromText(content, style) {
      const data = await post('/generate-from-text', {
        text: content.text,
        style,
        kind: content.kind || 'post',
        title: content.title || null,
        post_text: content.post_text || null,
      });
      return data.reply;
    },
    // `verify` (retries) makes the backend check X for an earlier copy of the
    // reply — including `previous` texts — before submitting anything.
    postReply(link, reply, like, verify, previous) {
      return post('/post-reply', {
        url: link,
        reply,
        like,
        verify_existing: Boolean(verify),
        previous_replies: previous || [],
      });
    },
    getLicenseStatus: () => apiRequest('/license/status'),
    getUsage: () => apiRequest('/license/usage'),
    activateLicense: (key) => post('/license/activate', { license_key: key }),
    logout: () => post('/license/logout'),
    getUsageSummary: (days) => apiRequest(`/usage/summary?days=${encodeURIComponent(days)}`),
    getPreferences: () => apiRequest('/preferences'),
    savePreferences: (changes) =>
      apiRequest('/preferences', { method: 'PUT', body: JSON.stringify(changes) }),
    openExternal: (url) => post('/open-external', { url }),
  };

  /* ==========================================================
     TOAST NOTIFICATIONS
  ========================================================== */
  const ToastManager = (() => {
    let container = null;
    const ICONS = { success: '✓', error: '✕', warning: '!', info: 'i' };

    function init() {
      container = document.createElement('div');
      container.className = 'toast-container';
      container.setAttribute('aria-live', 'polite');
      document.body.appendChild(container);
    }

    function show(message, type = 'info', duration = 5000) {
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;

      const iconEl = document.createElement('span');
      iconEl.className = 'toast-icon';
      iconEl.textContent = ICONS[type] || ICONS.info;

      // textContent, never innerHTML: messages carry server and exception
      // text, which must never be parsed as markup.
      const text = document.createElement('span');
      text.className = 'toast-message';
      text.textContent = message;

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'toast-close';
      closeBtn.setAttribute('aria-label', 'Dismiss notification');
      closeBtn.textContent = '×';

      toast.append(iconEl, text, closeBtn);
      container.appendChild(toast);

      const timer = setTimeout(() => dismiss(toast), duration);
      const dismissNow = (event) => {
        event.stopPropagation();
        clearTimeout(timer);
        dismiss(toast);
      };
      closeBtn.addEventListener('click', dismissNow);
      toast.addEventListener('click', dismissNow);
    }

    function dismiss(toast) {
      if (toast.dataset.dismissing) return;
      toast.dataset.dismissing = 'true';
      toast.classList.add('toast-out');
      // Never rely on animationend alone: under reduced motion it never fires.
      const remove = () => toast.remove();
      toast.addEventListener('animationend', remove, { once: true });
      setTimeout(remove, 300);
    }

    return { init, show };
  })();

  /* ==========================================================
     MODALS: center popup (run summaries) + confirm dialog
  ========================================================== */
  const Modal = (() => {
    // Builds an overlay + card; returns { overlay, card, close }.
    function create(cardClass) {
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay hidden';
      overlay.innerHTML = `<div class="modal-card ${cardClass}" role="dialog" aria-modal="true"></div>`;
      document.body.appendChild(overlay);
      return { overlay, card: overlay.firstElementChild };
    }
    return { create };
  })();

  const CenterPopup = (() => {
    let overlay = null;
    let card = null;
    const ICONS = { success: 'check', error: 'close', warning: 'alert-triangle' };

    function ensure() {
      if (overlay) return;
      ({ overlay, card } = Modal.create('cpopup-card'));
      card.setAttribute('role', 'alertdialog');
      card.innerHTML = `
        <button class="modal-close" type="button" aria-label="Close">${icon('close')}</button>
        <div class="cpopup-icon"></div>
        <p class="cpopup-message"></p>
        <button class="btn btn-solid cpopup-ok" type="button">Okay</button>`;
      card.querySelector('.modal-close').addEventListener('click', hide);
      card.querySelector('.cpopup-ok').addEventListener('click', hide);
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) hide();
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !overlay.classList.contains('hidden')) hide();
      });
    }

    function show(message, type = 'success') {
      ensure();
      const kind = ICONS[type] ? type : 'success';
      card.className = `modal-card cpopup-card cpopup-${kind}`;
      card.querySelector('.cpopup-icon').innerHTML = icon(ICONS[kind]);
      card.querySelector('.cpopup-message').textContent = message;
      overlay.classList.remove('hidden');
      card.querySelector('.cpopup-ok').focus();
    }

    function hide() {
      if (overlay) overlay.classList.add('hidden');
    }

    return { show, hide };
  })();

  const ConfirmDialog = (() => {
    let overlay = null;
    let card = null;
    let resolver = null;

    function ensure() {
      if (overlay) return;
      ({ overlay, card } = Modal.create('confirm-card'));
      card.innerHTML = `
        <div class="confirm-icon"></div>
        <h2 class="confirm-title"></h2>
        <p class="confirm-message"></p>
        <div class="confirm-actions">
          <button type="button" class="btn btn-ghost" data-answer="no">Cancel</button>
          <button type="button" class="btn btn-solid" data-answer="yes"></button>
        </div>`;
      card.querySelector('[data-answer="no"]').addEventListener('click', () => settle(false));
      card.querySelector('[data-answer="yes"]').addEventListener('click', () => settle(true));
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) settle(false);
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !overlay.classList.contains('hidden')) settle(false);
      });
    }

    function settle(answer) {
      overlay.classList.add('hidden');
      if (resolver) resolver(answer);
      resolver = null;
    }

    // Resolves true when confirmed, false otherwise.
    function ask({ title, message, confirmLabel = 'Confirm', danger = false, iconName = 'alert-circle' }) {
      ensure();
      card.classList.toggle('is-danger', danger);
      card.querySelector('.confirm-icon').innerHTML = icon(iconName);
      card.querySelector('.confirm-title').textContent = title;
      card.querySelector('.confirm-message').textContent = message;
      const yes = card.querySelector('[data-answer="yes"]');
      yes.textContent = confirmLabel;
      yes.className = `btn ${danger ? 'btn-danger' : 'btn-solid'}`;
      overlay.classList.remove('hidden');
      yes.focus();
      return new Promise((resolve) => {
        resolver = resolve;
      });
    }

    return { ask };
  })();

  // Run summaries honour the Notifications preference: a pop-up when on,
  // a brief toast when off.
  const Notify = {
    result(message, type = 'success') {
      if (state.prefs.notifications) CenterPopup.show(message, type);
      else ToastManager.show(message, type === 'success' ? 'success' : type, 7000);
    },
  };

  /* ==========================================================
     RUN STATUS BANNER
     Non-blocking progress for generate / post runs. Unlike a full
     overlay, links stay clickable underneath it.
  ========================================================== */
  const RunStatus = (() => {
    let banner = null;
    let titleEl = null;
    let detailEl = null;
    let fillEl = null;

    function init() {
      banner = document.getElementById('runBanner');
      titleEl = document.getElementById('runTitle');
      detailEl = document.getElementById('runDetail');
      fillEl = document.getElementById('runProgressFill');
    }

    function show(title, detail = '', progress = 0) {
      titleEl.textContent = title;
      setDetail(detail);
      setProgress(progress);
      banner.classList.remove('hidden');
    }

    function setTitle(title) {
      titleEl.textContent = title;
    }

    function setDetail(text) {
      detailEl.textContent = text || '';
    }

    function setProgress(percent) {
      fillEl.style.width = `${Math.max(0, Math.min(100, Number(percent) || 0))}%`;
    }

    function hide() {
      banner.classList.add('hidden');
    }

    return { init, show, setTitle, setDetail, setProgress, hide };
  })();

  /* ==========================================================
     POPOVERS (account menu, range menu)
  ========================================================== */
  const Popovers = (() => {
    const open = new Set();

    function bind(button, menu, { onSelect } = {}) {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const willOpen = menu.classList.contains('hidden');
        closeAll();
        if (willOpen) {
          menu.classList.remove('hidden');
          button.setAttribute('aria-expanded', 'true');
          open.add([button, menu]);
        }
      });
      menu.addEventListener('click', (e) => {
        const item = e.target.closest('.menu-item');
        if (!item) return;
        closeAll();
        if (onSelect) onSelect(item);
      });
    }

    function closeAll() {
      open.forEach(([button, menu]) => {
        menu.classList.add('hidden');
        button.setAttribute('aria-expanded', 'false');
      });
      open.clear();
    }

    function init() {
      document.addEventListener('click', closeAll);
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeAll();
      });
    }

    return { init, bind, closeAll };
  })();

  /* ==========================================================
     EXTERNAL LINKS
     Every X link opens in the user's default browser through the
     backend (webbrowser.open), never inside the XPilot window.
  ========================================================== */
  const LinkOpener = {
    async open(url) {
      try {
        await API.openExternal(url);
      } catch (err) {
        // Backend could not do it (e.g. dev page opened from disk) — let the
        // webview/browser try, and only complain if that fails too.
        const win = window.open(url, '_blank', 'noopener');
        if (!win) ToastManager.show(err.message || 'Could not open the link.', 'error');
      }
    },
    // Anchor wiring shared by the link field and reply cards.
    bind(anchor) {
      anchor.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const url = anchor.getAttribute('href');
        if (url && url !== '#') LinkOpener.open(url);
      });
    },
  };

  /* ==========================================================
     NAVIGATION
  ========================================================== */
  const Navigation = (() => {
    let navItems = [];
    let pages = {};
    let current = 'pilot';
    const enterHooks = {};

    function init() {
      navItems = Array.from(document.querySelectorAll('.nav-item'));
      pages = {
        pilot: document.getElementById('pilot-page'),
        usage: document.getElementById('usage-page'),
        settings: document.getElementById('settings-page'),
      };
      navItems.forEach((btn) => btn.addEventListener('click', () => goTo(btn.dataset.page)));
    }

    function onEnter(page, fn) {
      enterHooks[page] = fn;
    }

    function goTo(pageName) {
      if (!pages[pageName]) return;
      current = pageName;
      navItems.forEach((btn) => {
        const active = btn.dataset.page === pageName;
        btn.classList.toggle('active', active);
        if (active) btn.setAttribute('aria-current', 'page');
        else btn.removeAttribute('aria-current');
      });
      Object.entries(pages).forEach(([name, section]) => {
        section.classList.toggle('hidden', name !== pageName);
      });
      document.querySelector('.main-content').scrollTop = 0;
      if (enterHooks[pageName]) enterHooks[pageName]();
    }

    return { init, goTo, onEnter, current: () => current };
  })();

  /* ==========================================================
     LINK MANAGER
     One big paster box holds the batch's links (up to 100). It is the
     single source of truth: every link in it gets a field (link pill +
     reply card), fields keep their state when more links are pasted, and
     removing a link from the box removes its field.
  ========================================================== */
  const LinkManager = (() => {
    const MAX_LINKS = 100;
    const SYNC_DELAY_MS = 350;

    let rows = [];
    let rowSeq = 0;
    let paster = null;
    let linksList = null;
    let repliesList = null;
    let placeholder = null;
    let countValue = null;
    let countChip = null;
    let syncTimer = null;

    function init() {
      paster = document.getElementById('linkPaster');
      linksList = document.getElementById('linksList');
      repliesList = document.getElementById('repliesList');
      placeholder = document.getElementById('replyPlaceholder');
      countValue = document.getElementById('linkCountValue');
      countChip = document.getElementById('linkCountChip');

      paster.addEventListener('paste', handlePaste);
      paster.addEventListener('input', () => {
        autoGrowPaster();
        clearTimeout(syncTimer);
        syncTimer = setTimeout(() => sync(), SYNC_DELAY_MS);
      });
      paster.addEventListener('blur', () => {
        clearTimeout(syncTimer);
        sync();
      });

      document.getElementById('pasterGoBtn').addEventListener('click', () => {
        sync();
        document.getElementById('generateBtn').click();
      });
      document.getElementById('countDecBtn').addEventListener('click', () => {
        if (rows.length) removeRow(rows[rows.length - 1]);
      });
      document.getElementById('countIncBtn').addEventListener('click', focusNewLine);
      document.getElementById('addLinkBtn').addEventListener('click', focusNewLine);
      document.getElementById('clearBtn').addEventListener('click', confirmClear);

      autoGrowPaster();
      renderAll();
    }

    /* ---- The paster box ---- */

    // Unique links in the box, in order (case-insensitive, query stripped).
    function linksInPaster() {
      const seen = new Set();
      const links = [];
      extractLinks(paster.value).forEach((raw) => {
        const link = normalizeLink(raw);
        const key = link.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        links.push(link);
      });
      return links;
    }

    // Pasted links go in at the cursor as a clean one-per-line list (only the
    // ones not already in the box), and the cursor lands on a fresh line, so
    // the next batch can be pasted straight after.
    function handlePaste(e) {
      if (state.busy) return;
      const text = (e.clipboardData || window.clipboardData)?.getData('text') || '';
      const found = extractLinks(text);
      if (found.length === 0) return; // not links — ordinary paste

      e.preventDefault();
      const present = new Set(linksInPaster().map((l) => l.toLowerCase()));
      const room = Math.max(0, MAX_LINKS - present.size);
      const fresh = [];
      let duplicates = 0;
      found.forEach((raw) => {
        const link = normalizeLink(raw);
        const key = link.toLowerCase();
        if (present.has(key)) {
          duplicates += 1;
          return;
        }
        present.add(key);
        fresh.push(link);
      });
      const placed = fresh.slice(0, room);
      const dropped = fresh.length - placed.length;

      if (placed.length) {
        const before = paster.value.slice(0, paster.selectionStart);
        const lead = before && !before.endsWith('\n') ? '\n' : '';
        insertAtCursor(`${lead}${placed.join('\n')}\n`);
      }
      clearTimeout(syncTimer);
      sync();
      if (found.length > 1 || duplicates || dropped || placed.length === 0) {
        reportAdded({ placed: placed.length, duplicates, dropped });
      }
    }

    // Insert through the editing pipeline so Ctrl+Z still works.
    function insertAtCursor(text) {
      paster.focus();
      let ok = false;
      try {
        ok = document.execCommand('insertText', false, text);
      } catch (_) {
        ok = false;
      }
      if (!ok) {
        paster.setRangeText(text, paster.selectionStart, paster.selectionEnd, 'end');
      }
      autoGrowPaster();
    }

    function focusNewLine() {
      if (state.busy) return;
      if (rows.length >= MAX_LINKS) {
        ToastManager.show(`You can add up to ${MAX_LINKS} links per batch.`, 'warning');
        return;
      }
      paster.focus();
      const end = paster.value.length;
      paster.setSelectionRange(end, end);
      if (paster.value && !paster.value.endsWith('\n')) insertAtCursor('\n');
      paster.scrollTop = paster.scrollHeight;
    }

    function autoGrowPaster() {
      paster.style.height = 'auto';
      paster.style.height = `${paster.scrollHeight}px`;
    }

    function reportAdded({ placed, duplicates, dropped }) {
      const notes = [];
      if (duplicates > 0) notes.push(`${plural(duplicates, 'duplicate')} removed`);
      if (dropped > 0) notes.push(`${dropped} over the ${MAX_LINKS}-link limit skipped`);
      const message =
        `Added ${plural(placed, 'link')}` + (notes.length ? ` — ${notes.join(', ')}.` : '.');
      ToastManager.show(message, dropped > 0 || placed === 0 ? 'warning' : 'success');
    }

    // Make the fields match the box: new links get a field, links no longer in
    // the box lose theirs, existing fields keep their reply and status.
    let warnedOverLimit = false;
    function sync() {
      if (state.busy) return;
      let links = linksInPaster();
      if (links.length > MAX_LINKS) {
        if (!warnedOverLimit) {
          ToastManager.show(`Only the first ${MAX_LINKS} links are used — remove some to add others.`, 'warning');
          warnedOverLimit = true;
        }
        links = links.slice(0, MAX_LINKS);
      } else {
        warnedOverLimit = false;
      }

      // Nothing changed (e.g. the box just lost focus): leave the page alone.
      if (links.length === rows.length && links.every((link, i) => link.toLowerCase() === rows[i].link.toLowerCase())) {
        return;
      }

      const byKey = new Map(rows.map((r) => [r.link.toLowerCase(), r]));
      const next = links.map((link) => byKey.get(link.toLowerCase()) || createRow(link));
      const keep = new Set(next);
      rows.forEach((r) => {
        if (!keep.has(r)) destroyRow(r);
      });
      rows = next;
      // Keep DOM order identical to the box order — moving only what is out
      // of place. Re-inserting an element cancels a click that is in progress
      // on it (the box's blur runs this between mouse-down and mouse-up).
      rows.forEach((r, i) => {
        if (linksList.children[i] !== r.el.item) linksList.insertBefore(r.el.item, linksList.children[i] || null);
        if (repliesList.children[i] !== r.el.card) repliesList.insertBefore(r.el.card, repliesList.children[i] || null);
      });
      renderAll();
    }

    function syncCount() {
      countValue.textContent = String(rows.length);
      countChip.textContent = String(rows.length);
      document.getElementById('countDecBtn').disabled = Boolean(state.busy) || rows.length === 0;
      document.getElementById('countIncBtn').disabled = Boolean(state.busy) || rows.length >= MAX_LINKS;
    }

    /* ---- Row lifecycle ---- */
    function createRow(link) {
      rowSeq += 1;
      const row = {
        id: rowSeq,
        link,
        post: null, // content read from X: { text, kind, title, reply_url, post_text, link }
        gen: 'idle', // idle | queued | reading | generating | ready | failed
        genError: null,
        pub: 'none', // none | posting | posted | failed
        pubError: null,
        pubAttempts: 0,
        attemptedTexts: [], // every text we tried to publish (duplicate guard)
        liked: false,
        alreadyPosted: false,
        el: {},
      };

      const item = document.createElement('div');
      item.className = 'link-item';
      item.innerHTML = `
        <span class="link-badge" data-status="idle">${icon('link')}</span>
        <div class="link-field">
          <div class="link-display">
            <a class="link-anchor" href="#" rel="noopener noreferrer" title="Open in your browser"></a>
            ${icon('external', 'link-anchor-ext')}
          </div>
        </div>
        <span class="kind-tag hidden">${icon('article')}Article</span>
        <button type="button" class="link-remove" aria-label="Remove this link" title="Remove this link">${icon('close')}</button>
        <button type="button" class="link-go" aria-label="Generate a reply for this link" title="Generate a reply for this link">${icon('send')}</button>`;

      const card = document.createElement('div');
      card.className = 'reply-card';
      card.innerHTML = `
        <div class="reply-head">
          <span class="reply-label">Generated Reply <span class="reply-index"></span></span>
          <span class="reply-state"><span class="reply-state-text">Awaiting generation</span><span class="reply-state-icon">${icon('pending')}</span></span>
        </div>
        <div class="reply-source hidden">
          <a class="link-anchor" href="#" rel="noopener noreferrer" title="Open in your browser"></a>
          <span class="kind-tag"></span>
        </div>
        <textarea class="reply-output" rows="3" spellcheck="true" disabled
          placeholder="Your AI-generated reply will appear here.&#10;You can edit it before posting."></textarea>
        <div class="reply-error hidden" role="alert">${icon('alert-circle')}<span class="reply-error-text"></span></div>
        <div class="reply-actions">
          <button type="button" class="btn btn-outline post-btn" disabled>${icon('send')}<span>Post Reply</span></button>
          <button type="button" class="btn btn-outline copy-btn" disabled>${icon('copy')}<span>Copy</span></button>
        </div>`;

      row.el = {
        item,
        card,
        badge: item.querySelector('.link-badge'),
        anchor: item.querySelector('.link-display .link-anchor'),
        kindTag: item.querySelector('.kind-tag'),
        remove: item.querySelector('.link-remove'),
        go: item.querySelector('.link-go'),
        index: card.querySelector('.reply-index'),
        state: card.querySelector('.reply-state'),
        stateText: card.querySelector('.reply-state-text'),
        stateIcon: card.querySelector('.reply-state-icon'),
        source: card.querySelector('.reply-source'),
        sourceAnchor: card.querySelector('.reply-source .link-anchor'),
        sourceKind: card.querySelector('.reply-source .kind-tag'),
        output: card.querySelector('.reply-output'),
        error: card.querySelector('.reply-error'),
        errorText: card.querySelector('.reply-error-text'),
        postBtn: card.querySelector('.post-btn'),
        copyBtn: card.querySelector('.copy-btn'),
      };
      wireRow(row);
      return row;
    }

    function wireRow(row) {
      LinkOpener.bind(row.el.anchor);
      LinkOpener.bind(row.el.sourceAnchor);
      row.el.remove.addEventListener('click', () => removeRow(row));
      row.el.go.addEventListener('click', () => GenerateController.generateOne(row));
      row.el.postBtn.addEventListener('click', () => PostController.handlePostClick(row));
      row.el.copyBtn.addEventListener('click', () => handleCopy(row));
      row.el.output.addEventListener('input', () => {
        autoGrow(row.el.output);
        renderRow(row);
        BatchActions.refresh();
      });
    }

    function isLocked(row) {
      return Boolean(state.busy) || row.pub === 'posted' || row.pub === 'posting';
    }

    // Removing a field removes its link from the box (every copy of it).
    function removeRow(row) {
      if (state.busy) return;
      const key = row.link.toLowerCase();
      const withQuery = new RegExp(`${LINK_PATTERN.source}[^\\s]*`, 'gi');
      const lines = paster.value
        .replace(withQuery, (m) => (normalizeLink(m).toLowerCase() === key ? '' : m))
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);
      paster.value = lines.length ? `${lines.join('\n')}\n` : '';
      autoGrowPaster();
      sync();
    }

    function destroyRow(row) {
      row.el.item.remove();
      row.el.card.remove();
    }

    async function confirmClear() {
      if (state.busy) {
        ToastManager.show('Please wait for the current run to finish.', 'warning');
        return;
      }
      const hasContent = paster.value.trim() || rows.some((r) => r.el.output.value.trim());
      if (hasContent) {
        const ok = await ConfirmDialog.ask({
          title: 'Clear this batch?',
          message:
            'All links and generated replies will be removed from XPilot. Comments already posted stay on X.',
          confirmLabel: 'Clear all',
        });
        if (!ok) return;
      }
      reset();
      ToastManager.show('Cleared — ready for a new batch.', 'success');
    }

    // Empty box, no fields (new batch, or after logout).
    function reset() {
      paster.value = '';
      autoGrowPaster();
      rows.forEach(destroyRow);
      rows = [];
      renderAll();
    }

    /* ---- Reply output ---- */
    function autoGrow(textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.max(textarea.scrollHeight + 2, 96)}px`;
    }

    function setOutput(row, text) {
      row.el.output.value = text;
      autoGrow(row.el.output);
    }

    async function handleCopy(row) {
      const text = row.el.output.value.trim();
      if (!text) return;
      const ok = await copyText(text);
      ToastManager.show(ok ? 'Reply copied to clipboard.' : 'Could not copy the reply.', ok ? 'success' : 'error');
    }

    /* ---- Rendering ---- */
    function renderAll() {
      paster.readOnly = Boolean(state.busy);
      document.getElementById('pasterGoBtn').disabled = Boolean(state.busy) || rows.length === 0;
      linksList.classList.toggle('hidden', rows.length === 0);
      placeholder.classList.toggle('hidden', rows.length > 0);
      rows.forEach(renderRow);
      syncCount();
      BatchActions.refresh();
    }

    function renderRow(row) {
      const i = rows.indexOf(row) + 1;
      const many = rows.length > 1;
      const el = row.el;
      const kind = (row.post && row.post.kind) || classifyLink(row.link);
      const valid = Boolean(kind);
      const locked = isLocked(row);

      // Link pill
      el.anchor.href = row.link;
      el.anchor.textContent = displayLink(row.link);
      el.item.classList.toggle('is-locked', locked);
      el.kindTag.classList.toggle('hidden', kind !== 'article');
      el.badge.dataset.status = badgeStatus(row);
      el.remove.disabled = Boolean(state.busy) || row.pub === 'posting';
      el.go.disabled = Boolean(state.busy) || row.pub === 'posted';

      // Reply card
      el.index.textContent = many ? `#${i}` : '';
      el.source.classList.toggle('hidden', !(valid && many));
      if (valid && many) {
        el.sourceAnchor.href = row.link;
        el.sourceAnchor.textContent = displayLink(row.link);
        el.sourceKind.textContent = kind === 'article' ? 'Article' : 'Post';
      }

      const view = stateView(row);
      el.card.dataset.status = view.card;
      el.state.dataset.state = view.tone;
      el.stateText.textContent = view.text;
      el.stateIcon.innerHTML = view.spinner ? '<span class="state-spinner"></span>' : icon(view.icon);
      el.state.title = view.title || '';

      const message = rowMessage(row);
      el.error.classList.toggle('hidden', !message);
      if (message) {
        el.errorText.textContent = message.text;
        el.error.classList.toggle('is-warn', message.warn);
      }

      const text = el.output.value.trim();
      el.output.disabled = row.gen !== 'ready' || row.pub === 'posted' || row.pub === 'posting';
      el.copyBtn.disabled = !text;

      // While posting, the button shows its own spinner (setButtonLoading).
      if (row.pub === 'posting') return;
      el.postBtn.classList.toggle('is-posted', row.pub === 'posted');
      if (row.pub === 'posted') {
        el.postBtn.innerHTML = `${icon('check')}<span>${row.liked ? 'Posted &amp; Liked' : 'Posted'}</span>`;
        el.postBtn.disabled = true;
        return;
      }
      el.postBtn.innerHTML = `${icon(row.pub === 'failed' ? 'repeat' : 'send')}<span></span>`;
      el.postBtn.querySelector('span').textContent = row.pub === 'failed' ? 'Retry Post' : postButtonLabel();
      el.postBtn.disabled = Boolean(state.busy) || row.gen !== 'ready' || !replyTarget(row) || !text;
    }

    function badgeStatus(row) {
      if (row.pub === 'posted') return 'posted';
      if (row.pub === 'posting' || row.gen === 'reading' || row.gen === 'generating') return 'working';
      if (row.pub === 'failed' || row.gen === 'failed') return 'error';
      if (row.gen === 'ready') return 'ready';
      return 'idle';
    }

    // Label + icon for the reply card's status corner.
    function stateView(row) {
      const article = (row.post && row.post.kind) === 'article' || classifyLink(row.link) === 'article';
      if (row.pub === 'posted') {
        return {
          text: row.alreadyPosted ? 'Already posted' : row.liked ? 'Posted & liked' : 'Posted',
          icon: 'check-circle', tone: 'posted', card: 'posted',
          title: row.alreadyPosted ? 'An earlier attempt had already published this comment, so it was not posted again.' : '',
        };
      }
      if (row.pub === 'posting') {
        return { text: state.likesEnabled ? 'Posting & liking…' : 'Posting…', spinner: true, tone: 'working', card: '' };
      }
      if (row.pub === 'failed') {
        return {
          text: PostController.failureLabel(row.pubError),
          icon: 'alert-circle', tone: 'error', card: 'error',
          title: row.pubError?.message || '',
        };
      }
      switch (row.gen) {
        case 'queued':
          return { text: 'Queued', icon: 'pending', tone: '', card: '' };
        case 'reading':
          return { text: article ? 'Reading article…' : 'Reading post…', spinner: true, tone: 'working', card: '' };
        case 'generating':
          return { text: 'Generating…', spinner: true, tone: 'working', card: '' };
        case 'failed':
          return {
            text: GenerateController.failureLabel(row.genError),
            icon: 'alert-circle', tone: 'error', card: 'error',
            title: row.genError?.message || '',
          };
        case 'ready':
          return replyTarget(row)
            ? { text: 'Ready to post', icon: 'check-circle', tone: 'ready', card: '' }
            : { text: 'Ready — copy only', icon: 'alert-circle', tone: 'warn', card: '' };
        default:
          return { text: 'Awaiting generation', icon: 'pending', tone: '', card: '' };
      }
    }

    function rowMessage(row) {
      if (row.pub === 'failed' && row.pubError) return { text: row.pubError.message, warn: false };
      if (row.gen === 'failed' && row.genError) return { text: row.genError.message, warn: false };
      if (row.gen === 'ready' && row.pub === 'none' && !replyTarget(row)) {
        return {
          warn: true,
          text:
            "XPilot couldn't find the post that shares this X Article, so this reply can't be posted automatically. " +
            'Copy it, or paste the post link (x.com/…/status/…) instead of the article link.',
        };
      }
      return null;
    }

    return {
      init,
      reset,
      renderRow,
      renderAll,
      setOutput,
      getRows: () => rows,
    };
  })();

  // Where a row's reply gets published: the post itself, or for an X
  // Article the post that shares it. `null` = cannot be posted automatically.
  function replyTarget(row) {
    if (row.post) return row.post.reply_url || null;
    return classifyLink(row.link) === 'post' ? row.link : null;
  }

  function postButtonLabel() {
    return state.likesEnabled ? 'Post & Like' : 'Post Reply';
  }

  /* ==========================================================
     REPLY STYLES
  ========================================================== */
  const ReplyStyleManager = (() => {
    let cards = [];

    function init() {
      cards = Array.from(document.querySelectorAll('.style-card'));
      cards.forEach((card) => card.addEventListener('click', () => select(card.dataset.style)));
    }

    function select(styleName) {
      state.selectedStyle = styleName;
      cards.forEach((card) => {
        const on = card.dataset.style === styleName;
        card.classList.toggle('selected', on);
        card.setAttribute('aria-checked', String(on));
      });
    }

    function setDisabled(disabled) {
      cards.forEach((card) => {
        card.disabled = disabled;
      });
    }

    return { init, setDisabled, getSelected: () => state.selectedStyle };
  })();

  /* ==========================================================
     LIKES TOGGLE
  ========================================================== */
  const LikesController = (() => {
    let toggle = null;

    function init() {
      toggle = document.getElementById('enableLikesToggle');
      toggle.addEventListener('click', () => set(!state.likesEnabled));
      set(false);
    }

    function set(enabled) {
      state.likesEnabled = enabled;
      toggle.classList.toggle('switch-on', enabled);
      toggle.setAttribute('aria-checked', String(enabled));
      LinkManager.renderAll(); // post buttons follow the toggle
    }

    function setDisabled(disabled) {
      toggle.disabled = disabled;
    }

    return { init, setDisabled };
  })();

  /* ==========================================================
     BUSY STATE — one run at a time
  ========================================================== */
  function setBusy(kind) {
    state.busy = kind;
    const busy = Boolean(kind);
    ['generateBtn', 'addLinkBtn', 'clearBtn', 'logoutBtn'].forEach((id) => {
      const btn = document.getElementById(id);
      if (btn) btn.disabled = busy;
    });
    ReplyStyleManager.setDisabled(busy);
    LikesController.setDisabled(busy);
    LinkManager.renderAll();
  }

  /* ==========================================================
     GENERATE
     `run(rows)` reads each link (one at a time, human-paced) and
     generates its reply. Used by Generate Replies, the per-link
     button, and Regenerate Failed Replies — which passes only the
     failed rows, so successful replies are never touched.
  ========================================================== */
  const GenerateController = (() => {
    const FAILURE_LABELS = {
      invalid_post_url: 'Unsupported link',
      post_not_found: 'Post unavailable',
      article_unavailable: 'Article unavailable',
      article_restricted: 'Article restricted',
      article_incomplete: 'Article incomplete',
      navigation_failed: 'Network error',
      network_error: 'Connection lost',
      not_logged_in: 'Not signed in to X',
      browser_busy: 'Browser busy',
      generation_timeout: 'AI timed out',
      ai_provider_unavailable: 'AI unreachable',
      license_required: 'License required',
    };
    const FRIENDLY = {
      navigation_failed:
        "The link didn't load — check your internet connection, then use Regenerate Failed Replies.",
    };

    function failureLabel(error) {
      return (error && FAILURE_LABELS[error.code]) || 'Generation failed';
    }

    function toRowError(err) {
      const code = err.code || 'generation_failed';
      return { code, message: FRIENDLY[code] || err.message || 'The reply could not be generated.' };
    }

    function init() {
      document.getElementById('generateBtn').addEventListener('click', () => {
        const rows = LinkManager.getRows().filter((r) => r.link && r.pub !== 'posted');
        if (rows.length === 0) {
          const anyPosted = LinkManager.getRows().some((r) => r.pub === 'posted');
          ToastManager.show(
            anyPosted
              ? 'Every link in this batch is already posted. Clear the batch to start a new one.'
              : 'Paste at least one link before generating replies.',
            'warning'
          );
          return;
        }
        run(rows, { title: 'Generating replies' });
      });
    }

    async function generateOne(row) {
      if (state.busy || !row.link) return;
      if (row.pub === 'failed' && row.pubAttempts > 0) {
        const ok = await ConfirmDialog.ask({
          title: 'Write a new reply?',
          message:
            'Posting this reply failed earlier. If X actually accepted that attempt, posting a new, different reply would add a second comment. Generate a new reply anyway?',
          confirmLabel: 'Generate new reply',
        });
        if (!ok) return;
      }
      run([row], { title: 'Generating reply' });
    }

    function retryFailed() {
      const rows = failedRows();
      if (rows.length === 0) return;
      run(rows, { title: `Regenerating ${plural(rows.length, 'failed reply', 'failed replies')}`, retry: true });
    }

    function failedRows() {
      return LinkManager.getRows().filter((r) => r.gen === 'failed' && r.link && r.pub !== 'posted');
    }

    async function run(targetRows, { title, retry = false }) {
      if (state.busy) {
        ToastManager.show('Please wait for the current run to finish.', 'warning');
        return;
      }

      // Links that are not X posts/articles fail immediately, with a reason.
      const valid = [];
      targetRows.forEach((row) => {
        if (classifyLink(row.link)) {
          valid.push(row);
        } else {
          row.gen = 'failed';
          row.genError = {
            code: 'invalid_post_url',
            message:
              'This is not an X post or X Article link. Use a link like https://x.com/user/status/123 or https://x.com/i/article/123.',
          };
        }
      });
      LinkManager.renderAll();
      const invalidCount = targetRows.length - valid.length;
      if (valid.length === 0) {
        ToastManager.show('None of these links are X post or X Article links.', 'warning');
        return;
      }

      setBusy('generating');
      RunStatus.show('Connecting to X…', 'Checking your X login…', 0);

      try {
        // Pre-flight: make sure X is signed in BEFORE fetching anything. If
        // not, the login page opens and the whole queue waits here.
        const loggedIn = await waitForXLogin();
        if (!loggedIn) {
          ToastManager.show('Sign in to X in the XPilot window, then try again.', 'warning');
          return;
        }

        const style = ReplyStyleManager.getSelected();
        const total = valid.length;
        valid.forEach((row) => {
          row.gen = 'queued';
          row.genError = null;
          // A new reply replaces an unposted one; its publish state restarts.
          if (row.pub !== 'posted') {
            row.pub = 'none';
            row.pubError = null;
          }
        });
        LinkManager.renderAll();
        RunStatus.setTitle(`${title}…`);

        // Reads run one at a time (one shared browser tab), but each
        // generation is an independent network call — fire it as soon as its
        // content is read so generations overlap the remaining reads.
        let readDone = 0;
        let genDone = 0;
        const genPromises = [];
        const refreshProgress = () => {
          // Reads fill 0–50%, generations 50–100%; both against `total` so
          // the bar never jumps or slides back.
          RunStatus.setProgress((readDone / total) * 50 + (genDone / total) * 50);
        };

        for (let i = 0; i < total; i += 1) {
          const row = valid[i];
          let content = row.post && row.post.link === row.link ? row.post : null;
          let didRead = false;

          if (!content) {
            // Retry of a failed generation whose read worked reuses the text.
            const kind = classifyLink(row.link);
            RunStatus.setDetail(`Reading ${kind === 'article' ? 'article' : 'post'} ${i + 1}/${total}`);
            row.gen = 'reading';
            LinkManager.renderRow(row);
            try {
              const data = await API.readPost(row.link);
              content = { ...data, link: row.link };
              row.post = content;
            } catch (err) {
              console.error('readPost failed for', row.link, err);
              row.gen = 'failed';
              row.genError = toRowError(err);
              LinkManager.renderRow(row);
              readDone += 1;
              genDone += 1;
              refreshProgress();
              BatchActions.refresh();
              if (i < total - 1) await sleep(1500);
              continue;
            }
            didRead = true;
          }

          readDone += 1;
          row.gen = 'generating';
          LinkManager.renderRow(row);
          refreshProgress();

          const genPromise = API.generateFromText(content, style)
            .then((reply) => {
              LinkManager.setOutput(row, reply);
              row.gen = 'ready';
            })
            .catch((err) => {
              console.error('generateFromText failed for', row.link, err);
              row.gen = 'failed';
              row.genError = toRowError(err);
            })
            .finally(() => {
              genDone += 1;
              LinkManager.renderRow(row);
              BatchActions.refresh();
              RunStatus.setDetail(`Generated ${genDone}/${total}`);
              refreshProgress();
            });
          genPromises.push(genPromise);

          // Human pacing: pause before opening the next link.
          if (didRead && i < total - 1) {
            RunStatus.setDetail('Waiting a moment before the next link…');
            await sleep(3000);
          }
        }

        await Promise.all(genPromises);
        RunStatus.setProgress(100);

        const failed = valid.filter((r) => r.gen === 'failed').length + invalidCount;
        const all = total + invalidCount;
        const succeeded = all - failed;
        if (failed === 0) {
          Notify.result(
            retry
              ? `All ${plural(all, 'failed reply', 'failed replies')} regenerated successfully.`
              : `All ${plural(all, 'reply', 'replies')} generated successfully.`,
            'success'
          );
        } else {
          Notify.result(
            `${succeeded}/${all} replies generated; ${failed} failed. ` +
              'Each failed link shows why — use Regenerate Failed Replies to retry only those.',
            succeeded === 0 ? 'error' : 'warning'
          );
        }
      } catch (err) {
        // Unexpected stop (e.g. the backend went away): never leave rows
        // spinning — mark the unfinished ones failed so they can be retried.
        console.error('generation run stopped:', err);
        valid.forEach((row) => {
          if (['queued', 'reading', 'generating'].includes(row.gen)) {
            row.gen = 'failed';
            row.genError = toRowError(err);
          }
        });
        ToastManager.show(err.message || 'Generation stopped unexpectedly.', 'error', 9000);
      } finally {
        RunStatus.hide();
        setBusy(null);
        CreditsController.refresh();
        UsageController.markStale();
      }
    }

    // Ensures X is signed in before any fetching. Opens X (first check), then
    // polls the current page — WITHOUT reloading it — until the user signs in.
    async function waitForXLogin() {
      try {
        if (await API.checkLogin(true)) return true;
      } catch (err) {
        if (err.code === 'network_error' || err.code === 'license_required') throw err;
      }
      RunStatus.setTitle('Waiting for you to sign in to X…');
      RunStatus.setDetail(
        'Sign in to your X account in the XPilot window — generation starts automatically once you are signed in.'
      );
      const deadline = Date.now() + 5 * 60 * 1000;
      while (Date.now() < deadline) {
        await sleep(3000);
        try {
          if (await API.checkLogin(false)) return true;
        } catch (_) {
          // transient — keep waiting
        }
      }
      return false;
    }

    return { init, run, generateOne, retryFailed, failedRows, failureLabel };
  })();

  /* ==========================================================
     POSTING
  ========================================================== */
  //: Backend error codes that mean "no further post in this batch can succeed".
  const STOP_THE_RUN = ['reply_rate_limited', 'account_restricted', 'not_logged_in', 'network_error'];

  const PostController = (() => {
    const FAILURE_LABELS = {
      reply_rate_limited: 'Blocked by X (limit)',
      account_restricted: 'X account restricted',
      duplicate_reply: 'Duplicate reply',
      reply_not_allowed: 'Replies limited on this post',
      not_logged_in: 'Not signed in to X',
      post_not_found: 'Post unavailable',
      navigation_failed: 'Network error',
      network_error: 'Connection lost',
      chrome_profile_locked: 'Browser not available',
      cdp_port_in_use: 'Browser not available',
      browser_launch_failed: 'Browser not available',
      no_reply_target: 'No post to reply to',
    };

    function failureLabel(error) {
      return (error && FAILURE_LABELS[error.code]) || 'Post failed';
    }

    // Publishes one row. `retry` (and any row that failed before) asks the
    // backend to look for an earlier copy on X first, so a comment whose
    // first attempt actually landed is never posted twice.
    async function postRow(row, { retry = false } = {}) {
      const text = row.el.output.value.trim();
      const target = replyTarget(row);
      if (!target) {
        row.pub = 'failed';
        row.pubError = {
          code: 'no_reply_target',
          message: "There is no X post to attach this reply to. Paste the post that shares the article, or copy the reply.",
        };
        LinkManager.renderRow(row);
        return { ok: false, error: row.pubError };
      }

      const verify = retry || row.pubAttempts > 0;
      const previous = row.attemptedTexts.filter((t) => t !== text);
      row.pub = 'posting';
      row.pubError = null;
      row.pubAttempts += 1;
      if (!row.attemptedTexts.includes(text)) row.attemptedTexts.push(text);
      const restore = setButtonLoading(row.el.postBtn, state.likesEnabled ? 'Posting & liking…' : 'Posting…');
      LinkManager.renderRow(row);

      try {
        const result = await API.postReply(target, text, state.likesEnabled, verify, previous);
        row.pub = 'posted';
        row.liked = Boolean(result.liked);
        row.alreadyPosted = Boolean(result.already_posted);
        return { ok: true, already: row.alreadyPosted };
      } catch (err) {
        // On a retry, X calling it a duplicate means the earlier attempt went
        // through — the comment is there, so treat it as done, not failed.
        if (verify && err.code === 'duplicate_reply') {
          row.pub = 'posted';
          row.alreadyPosted = true;
          row.liked = false;
          return { ok: true, already: true };
        }
        console.error('postReply failed:', err);
        row.pub = 'failed';
        row.pubError = {
          code: err.code || 'post_reply_failed',
          message:
            err.code === 'network_error'
              ? 'XPilot lost contact while posting, so this comment may or may not have gone through. Repost Failed Comments checks X first and will not post it twice.'
              : err.message || 'The reply could not be posted.',
        };
        return { ok: false, error: err };
      } finally {
        restore();
        LinkManager.renderRow(row);
        BatchActions.refresh();
      }
    }

    async function handlePostClick(row) {
      if (state.busy || row.pub === 'posted' || row.pub === 'posting') return;
      if (!row.el.output.value.trim()) {
        ToastManager.show('The reply is empty — generate or write one first.', 'warning');
        return;
      }
      const retry = row.pub === 'failed';
      setBusy('posting');
      let result;
      try {
        result = await postRow(row, { retry });
      } finally {
        setBusy(null);
      }
      if (result.ok) {
        ToastManager.show(
          result.already
            ? 'This comment was already on X from an earlier attempt — it was not posted again.'
            : 'Reply posted successfully.',
          'success'
        );
      } else {
        ToastManager.show(result.error?.message || 'Failed to post reply.', 'error', 9000);
      }
    }

    // Sequential posting with a live banner. Shared by Post All and
    // Repost Failed Comments.
    async function postMany(rows, { retry }) {
      if (state.busy || rows.length === 0) return null;
      setBusy('posting');
      const total = rows.length;
      const verb = state.likesEnabled ? 'Posting & liking' : 'Posting';
      RunStatus.show(
        retry ? `Reposting ${plural(total, 'failed comment')}…` : `${verb} ${plural(total, 'reply', 'replies')}…`,
        `${verb} 1/${total}`,
        0
      );

      const outcome = { total, attempted: 0, posted: 0, already: 0, failed: 0, stoppedBy: null };
      try {
        for (let i = 0; i < total; i += 1) {
          RunStatus.setDetail(
            retry ? `Checking X, then reposting ${i + 1}/${total}` : `${verb} ${i + 1}/${total} (paced to look natural)`
          );
          outcome.attempted += 1;
          const result = await postRow(rows[i], { retry });
          if (result.ok && result.already) outcome.already += 1;
          else if (result.ok) outcome.posted += 1;
          else outcome.failed += 1;
          RunStatus.setProgress(((i + 1) / total) * 100);

          // Once X refuses the account (or the connection is gone), every
          // remaining post would fail the same way — stop and say why.
          if (result.error && STOP_THE_RUN.includes(result.error.code)) {
            outcome.stoppedBy = result.error;
            break;
          }
        }
      } finally {
        RunStatus.hide();
        setBusy(null);
      }
      return outcome;
    }

    function postableRows() {
      return LinkManager.getRows().filter(
        (r) => r.gen === 'ready' && r.pub === 'none' && replyTarget(r) && r.el.output.value.trim()
      );
    }

    function failedPostRows() {
      return LinkManager.getRows().filter(
        (r) => r.pub === 'failed' && replyTarget(r) && r.el.output.value.trim()
      );
    }

    async function postAll() {
      const outcome = await postMany(postableRows(), { retry: false });
      if (!outcome) return;
      const { total, posted, already, failed, stoppedBy, attempted } = outcome;
      const done = posted + already;
      if (stoppedBy) {
        Notify.result(
          `${stoppedBy.message} Stopped after ${done}/${total} posted — ${plural(total - attempted, 'reply', 'replies')} left unposted are still here.`,
          'error'
        );
      } else if (failed === 0) {
        Notify.result(
          `All ${plural(total, 'reply', 'replies')} posted${state.likesEnabled ? ' and liked' : ''} successfully.`,
          'success'
        );
      } else {
        Notify.result(
          `${done}/${total} replies posted; ${failed} failed. Use Repost Failed Comments to retry only those.`,
          done === 0 ? 'error' : 'warning'
        );
      }
    }

    async function repostFailed() {
      const outcome = await postMany(failedPostRows(), { retry: true });
      if (!outcome) return;
      const { total, posted, already, failed, stoppedBy } = outcome;
      const parts = [];
      if (posted) parts.push(`${plural(posted, 'comment')} reposted`);
      if (already) parts.push(`${already} already on X (not posted again)`);
      if (failed) parts.push(`${failed} still failing`);
      const summary = parts.join(', ') || 'Nothing to repost';
      if (stoppedBy) {
        Notify.result(`${stoppedBy.message} ${summary}.`, 'error');
      } else if (failed === 0) {
        Notify.result(`${summary}. All ${plural(total, 'failed comment')} resolved.`, 'success');
      } else {
        Notify.result(`${summary}. Each failed comment shows why.`, failed === total ? 'error' : 'warning');
      }
    }

    return { handlePostClick, postAll, repostFailed, postableRows, failedPostRows, failureLabel };
  })();

  /* ==========================================================
     BATCH ACTIONS
     Post All / Regenerate Failed Replies / Repost Failed Comments —
     each visible only when it has something to do.
  ========================================================== */
  const BatchActions = (() => {
    let wrap = null;
    let postAllBtn = null;
    let regenBtn = null;
    let repostBtn = null;

    function init() {
      wrap = document.getElementById('batchActions');
      postAllBtn = document.getElementById('postAllBtn');
      regenBtn = document.getElementById('regenFailedBtn');
      repostBtn = document.getElementById('repostFailedBtn');
      postAllBtn.addEventListener('click', () => PostController.postAll());
      regenBtn.addEventListener('click', () => GenerateController.retryFailed());
      repostBtn.addEventListener('click', () => PostController.repostFailed());
    }

    function setButton(btn, count, label, minimum = 1) {
      const show = count >= minimum;
      btn.classList.toggle('hidden', !show);
      btn.disabled = Boolean(state.busy);
      btn.querySelector('span').textContent = count > 0 ? `${label} (${count})` : label;
      return show;
    }

    function refresh() {
      if (!wrap) return;
      const allLabel = state.likesEnabled ? 'Post & Like All' : 'Post All Replies';
      const shown = [
        setButton(postAllBtn, PostController.postableRows().length, allLabel, 2),
        setButton(regenBtn, GenerateController.failedRows().length, 'Regenerate Failed Replies'),
        setButton(repostBtn, PostController.failedPostRows().length, 'Repost Failed Comments'),
      ];
      wrap.classList.toggle('hidden', !shown.some(Boolean));
    }

    return { init, refresh };
  })();

  /* ==========================================================
     CREDITS
     Daily / monthly credit usage from the license server, shown in
     Settings → Your Plan. Refreshed at startup and after each run.
  ========================================================== */
  const CreditsController = (() => {
    async function refresh() {
      if (!state.license || !state.license.activated) return;
      try {
        state.usage = (await API.getUsage()) || {};
      } catch (err) {
        console.error('usage refresh failed:', err);
        return;
      }
      SettingsController.renderPlanDetails();
    }

    return { init() {}, refresh };
  })();

  /* ==========================================================
     USAGE CHART
     Single-series area chart drawn as inline SVG: monotone curve,
     recessive grid, 8px markers, crosshair + tooltip on hover.
  ========================================================== */
  const UsageChart = (() => {
    const SVG_NS = 'http://www.w3.org/2000/svg';
    const PAD = { l: 44, r: 8, t: 16, b: 26 };
    let svg = null;
    let wrap = null;
    let tooltip = null;
    let data = null; // { points: [{label, tip, value, sub}] }

    function init() {
      svg = document.getElementById('usageChart');
      wrap = document.getElementById('chartWrap');
      tooltip = document.getElementById('chartTooltip');
      if ('ResizeObserver' in window) new ResizeObserver(() => draw()).observe(wrap);
      wrap.addEventListener('mouseleave', hideHover);
    }

    function render(points) {
      data = { points };
      draw();
    }

    function niceScale(max) {
      if (max <= 4) return { top: 4, step: 1 };
      const rough = max / 4;
      const mag = 10 ** Math.floor(Math.log10(rough));
      const norm = rough / mag;
      const step = Math.max(1, (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10) * mag);
      return { top: step * Math.max(4, Math.ceil(max / step)), step };
    }

    // Fritsch–Carlson monotone cubic: smooth like the reference, but never
    // overshoots below zero or above a peak.
    function monotonePath(pts) {
      const n = pts.length;
      if (n === 1) return `M${pts[0].x},${pts[0].y}`;
      const dx = [];
      const m = [];
      for (let i = 0; i < n - 1; i += 1) {
        dx.push(pts[i + 1].x - pts[i].x);
        m.push((pts[i + 1].y - pts[i].y) / (dx[i] || 1));
      }
      const t = new Array(n);
      t[0] = m[0];
      t[n - 1] = m[n - 2];
      for (let i = 1; i < n - 1; i += 1) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
      for (let i = 0; i < n - 1; i += 1) {
        if (m[i] === 0) {
          t[i] = 0;
          t[i + 1] = 0;
        } else {
          const a = t[i] / m[i];
          const b = t[i + 1] / m[i];
          const s = a * a + b * b;
          if (s > 9) {
            const tau = 3 / Math.sqrt(s);
            t[i] = tau * a * m[i];
            t[i + 1] = tau * b * m[i];
          }
        }
      }
      let d = `M${pts[0].x},${pts[0].y}`;
      for (let i = 0; i < n - 1; i += 1) {
        const h = dx[i] / 3;
        d += ` C${pts[i].x + h},${pts[i].y + t[i] * h} ${pts[i + 1].x - h},${pts[i + 1].y - t[i + 1] * h} ${pts[i + 1].x},${pts[i + 1].y}`;
      }
      return d;
    }

    function el(name, attrs, parent) {
      const node = document.createElementNS(SVG_NS, name);
      Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
      if (parent) parent.appendChild(node);
      return node;
    }

    function draw() {
      if (!svg || !data || wrap.offsetParent === null) return;
      const width = wrap.clientWidth;
      const height = wrap.clientHeight;
      const { points } = data;
      const n = points.length;
      if (!width || !height || n === 0) return;

      svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
      svg.innerHTML = '';
      const plotW = width - PAD.l - PAD.r;
      const plotH = height - PAD.t - PAD.b;
      const max = Math.max(0, ...points.map((p) => p.value));
      const { top, step } = niceScale(max);
      const x = (i) => PAD.l + (n === 1 ? plotW / 2 : (i * plotW) / (n - 1));
      const y = (v) => PAD.t + plotH - (v / top) * plotH;

      const defs = el('defs', {}, svg);
      const grad = el('linearGradient', { id: 'chartFill', x1: '0', y1: '0', x2: '0', y2: '1' }, defs);
      el('stop', { offset: '0%', style: 'stop-color: var(--chart-fill-top)' }, grad);
      el('stop', { offset: '100%', style: 'stop-color: var(--chart-fill-top); stop-opacity: 0' }, grad);

      // Y grid + labels
      for (let v = 0; v <= top + 1e-9; v += step) {
        const yy = y(v);
        el('line', { class: 'chart-grid-line', x1: PAD.l, x2: width - PAD.r, y1: yy, y2: yy }, svg);
        const label = el('text', { class: 'chart-axis-label', x: PAD.l - 19, y: yy + 4, 'text-anchor': 'end' }, svg);
        label.textContent = compactNumber(Math.round(v * 100) / 100);
      }

      // X labels (thinned to fit) + faint vertical guides
      // Every `every`-th point, plus the latest one when it isn't crammed
      // against the previous label.
      const maxLabels = Math.max(2, Math.floor(plotW / 58));
      const every = Math.max(1, Math.ceil(n / maxLabels));
      const lastRegular = (n - 1) - ((n - 1) % every);
      points.forEach((p, i) => {
        const regular = i % every === 0;
        const latest = i === n - 1 && !regular && (i - lastRegular) >= every * 0.6;
        if (!regular && !latest) return;
        el('line', { class: 'chart-grid-line', x1: x(i), x2: x(i), y1: PAD.t, y2: PAD.t + plotH }, svg);
        const label = el('text', { class: 'chart-axis-label', x: x(i), y: height - 3, 'text-anchor': 'middle' }, svg);
        label.textContent = p.label;
      });

      const coords = points.map((p, i) => ({ x: x(i), y: y(p.value) }));
      const line = monotonePath(coords);
      const baseline = y(0);
      el('path', {
        d: `${line} L${coords[n - 1].x},${baseline} L${coords[0].x},${baseline} Z`,
        fill: 'url(#chartFill)',
      }, svg);
      el('path', { class: 'chart-line', d: line }, svg);

      // Markers: every point for short series, just the latest for long ones.
      coords.forEach((c, i) => {
        if (n <= 31 || i === n - 1) el('circle', { class: 'chart-point', cx: c.x, cy: c.y, r: 3.8 }, svg);
      });

      // Hover layer
      const crosshair = el('line', { class: 'chart-crosshair hidden', y1: PAD.t, y2: PAD.t + plotH }, svg);
      const focus = el('circle', { class: 'chart-point hidden', r: 5.5 }, svg);
      const hit = el('rect', { x: PAD.l - 10, y: 0, width: plotW + 20, height, fill: 'transparent' }, svg);
      hit.addEventListener('mousemove', (e) => {
        const box = svg.getBoundingClientRect();
        const px = e.clientX - box.left;
        const i = n === 1 ? 0 : Math.max(0, Math.min(n - 1, Math.round(((px - PAD.l) / plotW) * (n - 1))));
        const c = coords[i];
        crosshair.setAttribute('x1', c.x);
        crosshair.setAttribute('x2', c.x);
        crosshair.classList.remove('hidden');
        focus.setAttribute('cx', c.x);
        focus.setAttribute('cy', c.y);
        focus.classList.remove('hidden');
        const p = points[i];
        tooltip.innerHTML = `<strong>${escapeHtml(p.tip)}</strong><span class="tt-value">${escapeHtml(p.valueText)}</span>` +
          (p.sub ? `<br><span class="tt-sub">${escapeHtml(p.sub)}</span>` : '');
        tooltip.style.left = `${Math.min(Math.max(c.x, 70), width - 70)}px`;
        tooltip.style.top = `${c.y}px`;
        tooltip.classList.remove('hidden');
      });
      hit.addEventListener('mouseleave', hideHover);
    }

    function hideHover() {
      if (tooltip) tooltip.classList.add('hidden');
      if (svg) svg.querySelectorAll('.chart-crosshair, circle[r="5.5"]').forEach((n) => n.classList.add('hidden'));
    }

    return { init, render, redraw: draw };
  })();

  /* ==========================================================
     USAGE PAGE
  ========================================================== */
  const UsageController = (() => {
    const RANGE_LABELS = { 7: 'Last 7 days', 30: 'Last 30 days', 90: 'Last 90 days' };
    const WEEKDAY = new Intl.DateTimeFormat(undefined, { weekday: 'short' });
    const DAY_MONTH = new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' });
    const FULL_DAY = new Intl.DateTimeFormat(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
    const MONTH = new Intl.DateTimeFormat(undefined, { month: 'short' });
    const MONTH_YEAR = new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' });

    let range = 7;
    let view = 'daily';
    let summary = null;
    let stale = true;
    let loading = false;

    function init() {
      Popovers.bind(document.getElementById('rangeBtn'), document.getElementById('rangeMenu'), {
        onSelect(item) {
          range = Number(item.dataset.range);
          document.getElementById('rangeLabel').textContent = RANGE_LABELS[range];
          document.querySelectorAll('#rangeMenu .menu-item').forEach((m) =>
            m.setAttribute('aria-selected', String(m === item))
          );
          load(true);
        },
      });
      document.querySelectorAll('.chart-card .segment').forEach((seg) => {
        seg.addEventListener('click', () => {
          view = seg.dataset.view;
          document.querySelectorAll('.chart-card .segment').forEach((s) => {
            const on = s === seg;
            s.classList.toggle('active', on);
            s.setAttribute('aria-selected', String(on));
          });
          renderChart();
        });
      });
      Navigation.onEnter('usage', () => load(stale));
      Navigation.onEnter('settings', () => CreditsController.refresh());
    }

    function markStale() {
      stale = true;
      if (Navigation.current() === 'usage') load(true);
    }

    async function load(force = false) {
      if (loading || (!force && summary)) {
        if (summary) renderChart();
        return;
      }
      loading = true;
      try {
        summary = await API.getUsageSummary(range);
        stale = false;
        renderCards();
        renderChart();
      } catch (err) {
        console.error('usage summary failed:', err);
        ToastManager.show(err.message || 'Could not load usage statistics.', 'error');
      } finally {
        loading = false;
      }
    }

    function renderCards() {
      const { totals, change_pct: change, previous } = summary;
      setStat('statReplies', totals.replies, change.replies, previous.replies, 'up');
      setStat('statFailed', totals.failed, change.failed, previous.failed, 'down');
      setStat('statTokens', totals.tokens, change.tokens, previous.tokens, 'up', true);
      document.getElementById('statTokensEst').classList.toggle('hidden', !summary.tokens_estimated);
      document.querySelectorAll('[data-compare]').forEach((node) => {
        node.textContent = `vs. previous ${range} days`;
      });
    }

    // `better` = which direction is good news ('up' for replies, 'down' for failures).
    function setStat(id, value, pct, previous, better, compact = false) {
      const valueEl = document.getElementById(id);
      valueEl.textContent = compact ? compactNumber(value) : Number(value).toLocaleString();
      valueEl.title = Number(value).toLocaleString();
      const delta = document.getElementById(`${id}Delta`);
      delta.className = 'stat-delta';
      if (pct === null || pct === undefined) {
        delta.innerHTML = value > 0 && previous === 0 ? '<span>New this period</span>' : '<span>—</span>';
        return;
      }
      if (pct === 0) {
        delta.innerHTML = '<span>0%</span>';
        return;
      }
      const up = pct > 0;
      const good = (better === 'up') === up;
      delta.classList.add(good ? 'is-good' : 'is-bad');
      delta.innerHTML = `${icon(up ? 'trend-up' : 'trend-down')}<span>${up ? '+' : ''}${pct}%</span>`;
    }

    function parseDay(key) {
      const [y, m, d] = key.split('-').map(Number);
      return new Date(y, m - 1, d);
    }

    function parseMonth(key) {
      const [y, m] = key.split('-').map(Number);
      return new Date(y, m - 1, 1);
    }

    function renderChart() {
      if (!summary) return;
      const empty = document.getElementById('chartEmpty');
      let points = [];

      if (view === 'daily') {
        points = summary.series.daily.map((p) => {
          const d = parseDay(p.key);
          return {
            label: range === 7 ? WEEKDAY.format(d) : DAY_MONTH.format(d),
            tip: FULL_DAY.format(d),
            value: p.replies,
            valueText: plural(p.replies, 'reply', 'replies'),
            sub: `${p.failed} failed · ${compactNumber(p.tokens)} tokens`,
          };
        });
      } else if (view === 'monthly') {
        points = summary.series.monthly.map((p) => {
          const d = parseMonth(p.key);
          return {
            label: d.getMonth() === 0 ? `${MONTH.format(d)} '${String(d.getFullYear()).slice(2)}` : MONTH.format(d),
            tip: MONTH_YEAR.format(d),
            value: p.replies,
            valueText: plural(p.replies, 'reply', 'replies'),
            sub: `${p.failed} failed · ${compactNumber(p.tokens)} tokens`,
          };
        });
      } else {
        points = summary.series.lifetime.map((p) => {
          const d = parseMonth(p.key);
          return {
            label: `${MONTH.format(d)} '${String(d.getFullYear()).slice(2)}`,
            tip: `Through ${MONTH_YEAR.format(d)}`,
            value: p.replies,
            valueText: `${p.replies.toLocaleString()} total`,
            sub: `${p.failed} failed · ${compactNumber(p.tokens)} tokens`,
          };
        });
      }

      empty.classList.toggle('hidden', points.some((p) => p.value > 0));
      UsageChart.render(points);
    }

    return { init, load, markStale };
  })();

  /* ==========================================================
     SETTINGS — license card + plan pills + account menu
  ========================================================== */
  const SettingsController = (() => {
    function init() {
      document.getElementById('copyKeyBtn').addEventListener('click', async () => {
        const key = state.license && (state.license.license_key_full || '');
        if (!key) return;
        const ok = await copyText(key);
        ToastManager.show(ok ? 'License key copied.' : 'Could not copy the license key.', ok ? 'success' : 'error');
      });
      document.getElementById('copyStatusBtn').addEventListener('click', async () => {
        const text = document.getElementById('licenseStatusText').textContent;
        const ok = await copyText(text);
        ToastManager.show(ok ? 'License status copied.' : 'Could not copy.', ok ? 'success' : 'error');
      });
      const planRow = document.getElementById('planRow');
      planRow.addEventListener('click', () => {
        const open = planRow.getAttribute('aria-expanded') !== 'true';
        planRow.setAttribute('aria-expanded', String(open));
        document.getElementById('planDetails').classList.toggle('hidden', !open);
      });
      document.getElementById('logoutBtn').addEventListener('click', () => LicenseController.logout());
    }

    function planName(status) {
      return status && status.plan ? capitalize(String(status.plan)) : 'XPilot';
    }

    function termLabel(status) {
      if (status.lifetime) return 'Lifetime';
      return status.expires_at ? `until ${formatDate(status.expires_at)}` : '';
    }

    function reflectLicense(status) {
      state.license = status;
      const active = Boolean(status && status.activated);
      const pillText = active ? `${planName(status)} • ${termLabel(status)}`.replace(/ • $/, '') : 'Not activated';

      document.querySelectorAll('[data-plan-pill]').forEach((pill) => {
        const upper = pill.classList.contains('plan-pill-upper');
        pill.querySelector('.plan-pill-text').textContent =
          upper && active ? pillText.replace(planName(status), planName(status).toUpperCase()) : pillText;
        pill.classList.toggle('is-active', active && !status.offline);
        pill.classList.toggle('is-offline', active && Boolean(status.offline));
        pill.classList.toggle('is-inactive', !active);
      });

      const statusText = document.getElementById('licenseStatusText');
      statusText.textContent = active
        ? `${status.offline ? 'Active (offline)' : 'Active'} — ${planName(status)} ${termLabel(status)}`.trim()
        : status?.message || 'Not activated';

      document.getElementById('licenseKeyText').textContent =
        (status && (status.license_key_full || status.license_key)) || '—';
      document.getElementById('copyKeyBtn').disabled = !(status && status.license_key_full);

      const activation = document.getElementById('activationBtn');
      activation.classList.toggle('is-offline', active && Boolean(status.offline));
      activation.innerHTML = active
        ? `${icon('check')}<span>${status.offline ? 'Activated (offline grace)' : 'Activated'}</span>`
        : `${icon('alert-circle')}<span>Not activated</span>`;

      document.getElementById('planName').textContent = active
        ? `${planName(status)} ${status.lifetime ? 'Lifetime' : 'Subscription'}`
        : '—';
      document.getElementById('planSub').textContent = active
        ? status.lifetime
          ? 'Full access to all features, forever.'
          : status.expires_at
            ? `Full access until ${formatDate(status.expires_at)}.`
            : 'Full access to all features.'
        : 'No active plan on this device.';

      document.getElementById('accountMenuPlan').textContent = active ? pillText : 'Not activated';
      document.getElementById('accountMenuKey').textContent = active ? `License ${status.license_key || ''}` : '';
      renderPlanDetails();
    }

    function renderPlanDetails() {
      const status = state.license || {};
      const usage = state.usage || status;
      const creditText = (used, cap) =>
        cap == null ? `${Number(used || 0).toLocaleString()} used · Unlimited` : `${Number(used || 0).toLocaleString()} / ${Number(cap).toLocaleString()} used`;
      document.getElementById('planExpires').textContent = !status.activated
        ? '—'
        : status.lifetime ? 'Never (lifetime)' : formatDate(status.expires_at);
      document.getElementById('planDaily').textContent = status.activated ? creditText(usage.daily_used, usage.daily_cap) : '—';
      document.getElementById('planMonthly').textContent = status.activated ? creditText(usage.monthly_used, usage.monthly_cap) : '—';
      document.getElementById('planDevice').textContent = status.hardware_id || '—';
    }

    return { init, reflectLicense, renderPlanDetails };
  })();

  const AccountMenu = {
    init() {
      Popovers.bind(document.getElementById('avatarBtn'), document.getElementById('accountMenu'), {
        onSelect(item) {
          const action = item.dataset.menu;
          if (action === 'help') HelpController.open();
          else if (action === 'settings') Navigation.goTo('settings');
          else if (action === 'logout') LicenseController.logout();
        },
      });
    },
  };

  /* ==========================================================
     PREFERENCES — appearance, language, notifications
     Persisted by the backend (WebView2 private mode discards
     localStorage between launches).
  ========================================================== */
  const PrefsController = (() => {
    let languages = [{ code: 'en-US', label: 'English (US)' }];
    const systemLight = window.matchMedia('(prefers-color-scheme: light)');

    function init() {
      document.querySelectorAll('.pref-row').forEach((row) => {
        row.addEventListener('click', () => {
          const open = row.getAttribute('aria-expanded') !== 'true';
          row.setAttribute('aria-expanded', String(open));
          document.querySelector(`[data-pref-body="${row.dataset.pref}"]`).classList.toggle('hidden', !open);
        });
      });
      document.querySelectorAll('[data-theme-choice]').forEach((btn) => {
        btn.addEventListener('click', () => save({ theme: btn.dataset.themeChoice }));
      });
      document.getElementById('notificationsToggle').addEventListener('click', () => {
        save({ notifications: !state.prefs.notifications });
      });
      systemLight.addEventListener('change', () => {
        if (state.prefs.theme === 'system') applyTheme();
      });
      render();
    }

    async function load() {
      try {
        const prefs = await API.getPreferences();
        if (prefs.available && Array.isArray(prefs.available.languages)) languages = prefs.available.languages;
        state.prefs = {
          theme: prefs.theme,
          language: prefs.language,
          notifications: Boolean(prefs.notifications),
          help_seen: Boolean(prefs.help_seen),
        };
      } catch (err) {
        console.error('preferences load failed:', err);
      }
      render();
    }

    function applyTheme() {
      const theme = state.prefs.theme === 'system' ? (systemLight.matches ? 'light' : 'dark') : state.prefs.theme;
      document.documentElement.dataset.theme = theme === 'light' ? 'light' : 'dark';
      UsageChart.redraw();
    }

    function render() {
      applyTheme();
      document.querySelectorAll('[data-theme-choice]').forEach((btn) => {
        const on = btn.dataset.themeChoice === state.prefs.theme;
        btn.classList.toggle('active', on);
        btn.setAttribute('aria-checked', String(on));
      });

      const current = languages.find((l) => l.code === state.prefs.language) || languages[0];
      document.getElementById('prefLanguageSub').textContent = current ? current.label : 'English (US)';
      const list = document.getElementById('languageChoices');
      list.innerHTML = '';
      languages.forEach((lang) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'choice';
        btn.setAttribute('role', 'radio');
        const on = lang.code === state.prefs.language;
        btn.setAttribute('aria-checked', String(on));
        btn.innerHTML = `<span>${escapeHtml(lang.label)}</span>${on ? icon('check') : ''}`;
        btn.addEventListener('click', () => {
          if (!on) save({ language: lang.code });
        });
        list.appendChild(btn);
      });

      const toggle = document.getElementById('notificationsToggle');
      toggle.classList.toggle('switch-on', state.prefs.notifications);
      toggle.setAttribute('aria-checked', String(state.prefs.notifications));
      document.getElementById('prefNotificationsSub').textContent = state.prefs.notifications
        ? 'Get notified about updates'
        : 'Run summaries are off';
    }

    // Optimistic: apply now, roll back if the backend refuses.
    async function save(changes) {
      const before = { ...state.prefs };
      state.prefs = { ...state.prefs, ...changes };
      render();
      try {
        await API.savePreferences(changes);
      } catch (err) {
        state.prefs = before;
        render();
        ToastManager.show(err.message || 'Could not save that preference.', 'error');
      }
    }

    return { init, load, save };
  })();

  /* ==========================================================
     LICENSE GATE
     Full-window activation screen: first launch, after logout,
     and whenever the saved license is no longer valid.
  ========================================================== */
  const LicenseGate = (() => {
    let gate = null;
    let input = null;
    let button = null;
    let errorEl = null;
    let subEl = null;
    let hwidEl = null;

    function init() {
      gate = document.createElement('div');
      gate.className = 'license-gate hidden';
      gate.innerHTML = `
        <div class="license-gate-card">
          <svg class="license-gate-logo" aria-hidden="true"><use href="#i-x-logo"/></svg>
          <h1 class="license-gate-title">Activate XPilot</h1>
          <p class="license-gate-sub">Enter your license key to unlock XPilot on this device.</p>
          <input class="text-input license-gate-input" type="text" placeholder="Enter your license key" spellcheck="false" autocomplete="off" aria-label="License key" />
          <div class="license-gate-error hidden" role="alert"></div>
          <button type="button" class="btn btn-solid license-gate-btn">Activate License</button>
          <p class="license-gate-hint">Device ID: <span class="license-gate-hwid">—</span></p>
        </div>`;
      document.body.appendChild(gate);

      input = gate.querySelector('.license-gate-input');
      button = gate.querySelector('.license-gate-btn');
      errorEl = gate.querySelector('.license-gate-error');
      subEl = gate.querySelector('.license-gate-sub');
      hwidEl = gate.querySelector('.license-gate-hwid');

      button.addEventListener('click', submit);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') submit();
      });
    }

    function show(status) {
      setError('');
      if (status) {
        if (status.message) subEl.textContent = status.message;
        if (status.hardware_id) hwidEl.textContent = shortHwid(status.hardware_id);
      }
      input.value = '';
      gate.classList.remove('hidden');
      setTimeout(() => input.focus(), 50);
    }

    function hide() {
      gate.classList.add('hidden');
    }

    function shortHwid(hwid) {
      return hwid.length > 16 ? `${hwid.slice(0, 8)}…${hwid.slice(-4)}` : hwid;
    }

    function setError(message) {
      errorEl.textContent = message || '';
      errorEl.classList.toggle('hidden', !message);
    }

    async function submit() {
      const key = input.value.trim();
      if (!key) {
        setError('Please enter your license key.');
        input.focus();
        return;
      }
      setError('');
      const restore = setButtonLoading(button, 'Activating…');
      try {
        await LicenseController.activate(key);
        ToastManager.show('License activated. Welcome to XPilot!', 'success');
      } catch (err) {
        console.error('activation failed:', err);
        setError(err.message || 'Activation failed. Check your key and try again.');
      } finally {
        restore();
      }
    }

    return { init, show, hide };
  })();

  /* ==========================================================
     LICENSE CONTROLLER
     Single source of truth for license state: status, activation,
     logout — drives the gate, settings and plan pills.
  ========================================================== */
  const LicenseController = (() => {
    let refreshing = null;

    function refresh() {
      if (refreshing) return refreshing;
      refreshing = (async () => {
        let status;
        try {
          status = await API.getLicenseStatus();
        } catch (err) {
          console.error('license status check failed:', err);
          status = {
            activated: false,
            message: 'Cannot reach the XPilot backend. Make sure it is running, then reopen the app.',
          };
        }
        SettingsController.reflectLicense(status);
        if (status.activated) {
          LicenseGate.hide();
          CreditsController.refresh();
          UsageController.markStale();
          HelpController.maybeAutoShow();
        } else {
          LicenseGate.show(status);
        }
        return status;
      })().finally(() => {
        refreshing = null;
      });
      return refreshing;
    }

    // Validates through the backend's existing activation flow, then
    // refreshes every license-aware part of the UI.
    async function activate(key) {
      const result = await API.activateLicense(key);
      await refresh();
      return result;
    }

    async function logout() {
      Popovers.closeAll();
      if (state.busy) {
        ToastManager.show('Please wait for the current run to finish before logging out.', 'warning');
        return;
      }
      const ok = await ConfirmDialog.ask({
        title: 'Log out of XPilot?',
        message:
          'This deactivates your license on this device and returns to the activation screen, where you can enter this or a different license key. Links and unposted replies in Pilot will be cleared.',
        confirmLabel: 'Log out',
        danger: true,
        iconName: 'logout',
      });
      if (!ok) return;

      const btn = document.getElementById('logoutBtn');
      const restore = setButtonLoading(btn, 'Logging out…');
      let status;
      try {
        status = await API.logout();
      } catch (err) {
        restore();
        ToastManager.show(err.message || 'Could not log out. Please try again.', 'error');
        return;
      }
      restore();
      state.usage = null;
      LinkManager.reset();
      Navigation.goTo('pilot');
      SettingsController.reflectLicense(status);
      LicenseGate.show(status);
      ToastManager.show('Logged out. Enter a license key to continue.', 'success');
    }

    return { refresh, activate, logout };
  })();

  /* ==========================================================
     HELP / SETUP GUIDE
  ========================================================== */
  const HelpController = (() => {
    let modal = null;

    function init() {
      modal = document.getElementById('helpModal');
      document.getElementById('footerHelpBtn').addEventListener('click', open);
      document.getElementById('helpClose').addEventListener('click', close);
      document.getElementById('helpGotIt').addEventListener('click', close);
      modal.addEventListener('click', (e) => {
        if (e.target === modal) close();
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) close();
      });
    }

    function open() {
      modal.classList.remove('hidden');
      document.getElementById('helpGotIt').focus();
    }

    function close() {
      modal.classList.add('hidden');
    }

    // Shown once after the first activation; reopenable from the account
    // menu or the sidebar footer.
    function maybeAutoShow() {
      if (state.prefs.help_seen) return;
      PrefsController.save({ help_seen: true });
      open();
    }

    return { init, open, close, maybeAutoShow };
  })();

  /* ==========================================================
     SCROLL JUMP BUTTON
  ========================================================== */
  const ScrollJump = (() => {
    const EDGE_PX = 4;
    let btn = null;
    let scroller = null;
    let pointingUp = false;

    function init() {
      btn = document.getElementById('scrollJumpBtn');
      scroller = document.querySelector('.main-content');
      btn.addEventListener('click', jump);
      scroller.addEventListener('scroll', update, { passive: true });
      window.addEventListener('resize', update);
      if ('ResizeObserver' in window) {
        const observer = new ResizeObserver(update);
        Array.from(scroller.children).forEach((child) => observer.observe(child));
      }
      new MutationObserver(update).observe(scroller, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class'],
      });
      update();
    }

    function maxScroll() {
      return scroller.scrollHeight - scroller.clientHeight;
    }

    function update() {
      const max = maxScroll();
      btn.classList.toggle('hidden', max <= EDGE_PX);
      if (max <= EDGE_PX) return;
      const up = scroller.scrollTop >= max - EDGE_PX || scroller.scrollTop > max / 2;
      if (up === pointingUp) return;
      pointingUp = up;
      btn.classList.toggle('is-up', up);
      const label = up ? 'Scroll to top' : 'Scroll to bottom';
      btn.setAttribute('aria-label', label);
      btn.title = label;
    }

    function jump() {
      const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      scroller.scrollTo({ top: pointingUp ? 0 : maxScroll(), behavior: reduceMotion ? 'auto' : 'smooth' });
    }

    return { init };
  })();

  /* ==========================================================
     BOOTSTRAP
  ========================================================== */
  document.addEventListener('DOMContentLoaded', async () => {
    ToastManager.init();
    RunStatus.init();
    Popovers.init();
    LicenseGate.init();

    Navigation.init();
    ReplyStyleManager.init();
    BatchActions.init();
    LinkManager.init();
    LikesController.init();
    GenerateController.init();
    CreditsController.init();
    UsageChart.init();
    UsageController.init();
    SettingsController.init();
    AccountMenu.init();
    PrefsController.init();
    HelpController.init();
    ScrollJump.init();

    // Gate first (so nothing is usable before the license check), apply the
    // saved theme, then check the license.
    LicenseGate.show({ message: 'Checking your license…' });
    await PrefsController.load();
    LicenseController.refresh();
  });
})();
