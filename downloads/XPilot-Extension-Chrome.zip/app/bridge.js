/**
 * XPilot extension — bridge.
 * ------------------------------------------------------------------
 * The extension shows the desktop app's own interface (index.html,
 * style.css, script.js, copied at build time). In the app that interface
 * talks to a local Python backend over HTTP; here, script.js hands every
 * API call to `window.XPilotBridge.request(path, options)` instead, and this
 * file answers it inside the browser with the same response shapes:
 *
 *   licensing + usage   -> the same XPilot server (/api/license, /api/generate)
 *   reading / posting   -> an X tab driven through content.js
 *   stats + preferences -> extension storage
 *
 * Nothing here talks to X's servers directly; all X work happens in a real
 * x.com tab in the user's own signed-in browser.
 * ------------------------------------------------------------------ */
(() => {
  'use strict';

  const ext = globalThis.browser || globalThis.chrome;
  const CFG = window.XPILOT_CONFIG;
  const API = CFG.apiBase.replace(/\/+$/, '');
  const X_ORIGIN = CFG.xOrigin.replace(/\/+$/, '');

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function fail(code, message, status = 400, details = null) {
    const error = new Error(message);
    error.code = code;
    error.status = status;
    error.details = details;
    return error;
  }

  /* ---------------------------------------------------------------
     Storage
  --------------------------------------------------------------- */
  const store = {
    async get(key, fallback = null) {
      const result = await ext.storage.local.get(key);
      return result[key] === undefined ? fallback : result[key];
    },
    set(key, value) {
      return ext.storage.local.set({ [key]: value });
    },
    remove(key) {
      return ext.storage.local.remove(key);
    },
  };

  async function installId() {
    let id = await store.get('installId');
    if (!id) {
      id = crypto.randomUUID();
      await store.set('installId', id);
    }
    return id;
  }

  /* ---------------------------------------------------------------
     URL validation (xpilot/api/validation.py)
  --------------------------------------------------------------- */
  const X_POST_URL = /^https?:\/\/(www\.|mobile\.)?(x|twitter)\.com\/[A-Za-z0-9_]{1,15}\/status\/\d+/i;
  const X_ARTICLE_URL = /^https?:\/\/(www\.|mobile\.)?(x|twitter)\.com\/(i|[A-Za-z0-9_]{1,15})\/article\/\d+/i;
  const EXTERNAL_HOSTS = new Set(['x.com', 'www.x.com', 'mobile.x.com', 'twitter.com', 'www.twitter.com', 'mobile.twitter.com']);

  function requireString(body, field, maxLength) {
    const value = body ? body[field] : undefined;
    if (typeof value !== 'string' || !value.trim()) {
      throw fail('validation_error', `Field '${field}' is required and must be a non-empty string.`);
    }
    const trimmed = value.trim();
    if (trimmed.length > maxLength) {
      throw fail('validation_error', `Field '${field}' exceeds the maximum length of ${maxLength} characters.`);
    }
    return trimmed;
  }

  function validateReadableUrl(url) {
    if (X_POST_URL.test(url) || X_ARTICLE_URL.test(url)) return url;
    throw fail(
      'invalid_post_url',
      'This link is not an X post or X Article, so XPilot cannot read it. Supported links look like https://x.com/username/status/123 or https://x.com/i/article/123.',
      400,
      { url }
    );
  }

  function validatePostUrl(url) {
    if (X_POST_URL.test(url)) return url;
    if (X_ARTICLE_URL.test(url)) {
      throw fail(
        'invalid_post_url',
        'Replies are posted to the post that shares an X Article, not to the article page itself. Paste the post\'s link (https://x.com/username/status/…) to reply.',
        400,
        { url }
      );
    }
    throw fail('invalid_post_url', 'The URL must be an X post link, e.g. https://x.com/username/status/1234567890.', 400, { url });
  }

  const isArticleUrl = (url) => X_ARTICLE_URL.test(url);

  /* ---------------------------------------------------------------
     Licensing (xpilot/licensing/manager.py + client.py)
  --------------------------------------------------------------- */
  async function licenseCall(payload) {
    let res;
    try {
      res = await fetch(`${API}/api/license`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch (_) {
      throw fail('license_service_unavailable', 'The licensing service is unreachable. Check your internet connection and try again.', 503);
    }
    let data = {};
    try {
      data = (await res.json()) || {};
    } catch (_) {
      data = {};
    }
    return {
      success: res.ok && Boolean(data.success),
      data,
      message: String(data.message || data.error || ''),
      errorCode: String(data.error || ''),
    };
  }

  const License = (() => {
    const GRACE_MS = CFG.offlineGraceDays * 24 * 3600 * 1000;
    let state = null;
    let ready = null;

    const mask = (key) => (key.length <= 4 ? '****' : `****${key.slice(-4)}`);
    const blank = {
      daily_used: null,
      daily_cap: null,
      monthly_used: null,
      monthly_cap: null,
    };

    function activatedState(rec, offline) {
      return {
        activated: true,
        plan: rec.plan,
        expires_at: rec.expires_at ?? null,
        lifetime: rec.expires_at == null,
        license_key: mask(rec.license_key),
        license_key_full: rec.license_key,
        offline,
        message: offline ? 'License active (offline).' : 'License active.',
        ...blank,
      };
    }

    function inactive(message, rec = null) {
      return {
        activated: false,
        plan: null,
        expires_at: null,
        lifetime: false,
        license_key: rec ? mask(rec.license_key) : null,
        license_key_full: null,
        offline: false,
        message,
        ...blank,
      };
    }

    function applyUsage(data) {
      ['daily_used', 'daily_cap', 'monthly_used', 'monthly_cap'].forEach((field) => {
        state[field] = typeof data[field] === 'number' ? data[field] : null;
      });
    }

    function offlineState(rec) {
      const expiry = rec.expires_at ? Date.parse(rec.expires_at) : NaN;
      if (!Number.isNaN(expiry) && expiry < Date.now()) return inactive('This license has expired.', rec);
      const last = rec.last_validated ? Date.parse(rec.last_validated) : NaN;
      if (!Number.isNaN(last) && Date.now() - last > GRACE_MS) {
        return inactive(
          'XPilot could not verify your license and the offline grace period has ended. Reconnect to the internet to continue.',
          rec
        );
      }
      return activatedState(rec, true);
    }

    // Startup validation of the saved license (validate_on_startup).
    async function validate() {
      const rec = await store.get('license');
      if (!rec) {
        state = inactive('No license found. Please activate XPilot.');
        return;
      }
      let result;
      try {
        result = await licenseCall({ action: 'check', license_key: rec.license_key, hardware_id: await installId() });
      } catch (_) {
        state = offlineState(rec);
        return;
      }
      if (result.success) {
        const updated = {
          ...rec,
          plan: String(result.data.plan ?? rec.plan),
          expires_at: 'expires_at' in result.data ? result.data.expires_at : rec.expires_at,
          last_validated: new Date().toISOString(),
        };
        await store.set('license', updated);
        state = activatedState(updated, false);
        applyUsage(result.data);
        return;
      }
      state = inactive(result.message || 'Your license is no longer valid.', rec);
    }

    function whenReady() {
      if (!ready) ready = validate();
      return ready;
    }

    async function status() {
      await whenReady();
      return { ...state, hardware_id: await installId() };
    }

    async function activate(key) {
      await whenReady();
      const licenseKey = String(key || '').trim();
      if (!licenseKey) throw fail('license_invalid', 'A license key is required.', 403);
      const hardwareId = await installId();
      const result = await licenseCall({ action: 'activate', license_key: licenseKey, hardware_id: hardwareId });
      if (!result.success) {
        throw fail(
          'license_invalid',
          result.message || 'This license could not be activated.',
          403,
          result.errorCode ? { code: result.errorCode } : null
        );
      }
      const rec = {
        license_key: licenseKey,
        hardware_id: hardwareId,
        plan: String(result.data.plan ?? 'plus'),
        expires_at: result.data.expires_at ?? null,
        activated: true,
        last_validated: new Date().toISOString(),
      };
      await store.set('license', rec);
      state = activatedState(rec, false);
      return { ...state };
    }

    async function logout() {
      await whenReady();
      await store.remove('license');
      state = inactive('You have been logged out. Enter a license key to continue.');
      return { ...state, hardware_id: await installId() };
    }

    async function refreshUsage() {
      await whenReady();
      const snapshot = () => ({
        daily_used: state.daily_used,
        daily_cap: state.daily_cap,
        monthly_used: state.monthly_used,
        monthly_cap: state.monthly_cap,
      });
      if (!state.activated || !state.license_key_full) return snapshot();
      try {
        const result = await licenseCall({ action: 'check', license_key: state.license_key_full, hardware_id: await installId() });
        if (result.success) applyUsage(result.data);
      } catch (_) {
        // keep the last known numbers
      }
      return snapshot();
    }

    return {
      whenReady,
      status,
      activate,
      logout,
      refreshUsage,
      isActivated: () => Boolean(state && state.activated),
      keyFull: () => (state && state.license_key_full) || null,
    };
  })();

  /* ---------------------------------------------------------------
     Usage statistics (xpilot/usage/tracker.py)
  --------------------------------------------------------------- */
  const Usage = (() => {
    const FIELDS = ['replies', 'failed', 'tokens', 'articles', 'estimated'];
    const RANGES = [7, 30, 90];
    const pad = (n) => String(n).padStart(2, '0');
    const isoDay = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
    const monthKey = (y, m) => `${y}-${pad(m)}`;
    const addMonths = (y, m, delta) => {
      const index = y * 12 + (m - 1) + delta;
      return [Math.floor(index / 12), (index % 12) + 1];
    };
    let queue = Promise.resolve();

    async function bucket() {
      const key = License.keyFull();
      if (!key) return 'unlicensed';
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key));
      return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('')
        .slice(0, 16);
    }

    async function load() {
      const data = await store.get('usage');
      return data && typeof data.licenses === 'object' ? data : { version: 1, licenses: {} };
    }

    function record({ ok, kind = 'post', tokens = 0, estimated = false }) {
      queue = queue
        .then(async () => {
          const data = await load();
          const lic = await bucket();
          const days = (data.licenses[lic] = data.licenses[lic] || {});
          const today = isoDay(new Date());
          const b = (days[today] = days[today] || {});
          FIELDS.forEach((f) => {
            b[f] = b[f] || 0;
          });
          if (ok) {
            b.replies += 1;
            if (kind === 'article') b.articles += 1;
          } else {
            b.failed += 1;
          }
          if (tokens > 0) {
            b.tokens += Math.round(tokens);
            if (estimated) b.estimated += 1;
          }
          await store.set('usage', data);
        })
        .catch(() => {});
      return queue;
    }

    const pct = (current, previous) => (previous <= 0 ? null : Math.round(((current - previous) / previous) * 1000) / 10);

    async function summary(daysArg) {
      const days = RANGES.includes(daysArg) ? daysArg : 7;
      await queue;
      const data = await load();
      const map = data.licenses[await bucket()] || {};
      const today = new Date();
      const current = [];
      for (let offset = days - 1; offset >= 0; offset -= 1) current.push(addDays(today, -offset));
      const previous = current.map((d) => addDays(d, -days));

      const total = (window_) => {
        const sums = Object.fromEntries(FIELDS.map((f) => [f, 0]));
        window_.forEach((d) => {
          const b = map[isoDay(d)];
          if (b) FIELDS.forEach((f) => (sums[f] += Number(b[f] || 0)));
        });
        return sums;
      };
      const cur = total(current);
      const prev = total(previous);
      const life = Object.fromEntries(FIELDS.map((f) => [f, 0]));
      Object.values(map).forEach((b) => FIELDS.forEach((f) => (life[f] += Number(b[f] || 0))));

      const point = (key) => {
        const b = map[key] || {};
        return { key, replies: Number(b.replies || 0), failed: Number(b.failed || 0), tokens: Number(b.tokens || 0) };
      };
      const months = {};
      Object.entries(map).forEach(([key, b]) => {
        const m = (months[key.slice(0, 7)] = months[key.slice(0, 7)] || { replies: 0, failed: 0, tokens: 0 });
        ['replies', 'failed', 'tokens'].forEach((f) => (m[f] += Number(b[f] || 0)));
      });
      const monthly = [];
      for (let back = 11; back >= 0; back -= 1) {
        const [y, m] = addMonths(today.getFullYear(), today.getMonth() + 1, -back);
        const key = monthKey(y, m);
        const v = months[key] || {};
        monthly.push({ key, replies: v.replies || 0, failed: v.failed || 0, tokens: v.tokens || 0 });
      }
      const end = [today.getFullYear(), today.getMonth() + 1];
      const keys = Object.keys(months).sort();
      let start = keys.length ? [Number(keys[0].slice(0, 4)), Number(keys[0].slice(5, 7))] : addMonths(end[0], end[1], -5);
      if (start[0] === end[0] && start[1] === end[1]) start = addMonths(end[0], end[1], -1);
      const lifetime = [];
      const running = { replies: 0, failed: 0, tokens: 0 };
      let [y, m] = start;
      while (y < end[0] || (y === end[0] && m <= end[1])) {
        const key = monthKey(y, m);
        ['replies', 'failed', 'tokens'].forEach((f) => (running[f] += (months[key] || {})[f] || 0));
        lifetime.push({ key, ...running });
        [y, m] = addMonths(y, m, 1);
      }

      return {
        range_days: days,
        totals: { replies: cur.replies, failed: cur.failed, tokens: cur.tokens, articles: cur.articles },
        previous: { replies: prev.replies, failed: prev.failed, tokens: prev.tokens },
        change_pct: { replies: pct(cur.replies, prev.replies), failed: pct(cur.failed, prev.failed), tokens: pct(cur.tokens, prev.tokens) },
        lifetime: { replies: life.replies, failed: life.failed, tokens: life.tokens, articles: life.articles },
        tokens_estimated: cur.estimated > 0,
        first_day: Object.keys(map).sort()[0] || null,
        series: { daily: current.map((d) => point(isoDay(d))), monthly, lifetime },
      };
    }

    return { record, summary };
  })();

  /* ---------------------------------------------------------------
     Preferences (xpilot/config.py PreferencesConfig)
  --------------------------------------------------------------- */
  const Prefs = (() => {
    const DEFAULTS = { theme: 'dark', language: 'en-US', notifications: true, help_seen: false };
    const THEMES = ['system', 'dark', 'light'];
    const LANGUAGES = { 'en-US': 'English (US)' };

    async function current() {
      return { ...DEFAULTS, ...(await store.get('preferences', {})) };
    }

    async function get() {
      return {
        ...(await current()),
        available: { themes: THEMES, languages: Object.entries(LANGUAGES).map(([code, label]) => ({ code, label })) },
      };
    }

    async function put(body) {
      if (!body || typeof body !== 'object') throw fail('validation_error', 'Request body must be a JSON object.');
      const changes = {};
      if ('theme' in body) {
        if (!THEMES.includes(body.theme)) throw fail('validation_error', `Theme must be one of: ${THEMES.join(', ')}.`);
        changes.theme = body.theme;
      }
      if ('language' in body) {
        if (!(body.language in LANGUAGES)) throw fail('validation_error', 'That language is not available in this version.');
        changes.language = body.language;
      }
      ['notifications', 'help_seen'].forEach((flag) => {
        if (flag in body) {
          if (typeof body[flag] !== 'boolean') throw fail('validation_error', `'${flag}' must be true or false.`);
          changes[flag] = body[flag];
        }
      });
      if (!Object.keys(changes).length) throw fail('validation_error', 'Provide at least one preference to change.');
      const updated = { ...(await current()), ...changes };
      await store.set('preferences', updated);
      return updated;
    }

    return { get, put };
  })();

  /* ---------------------------------------------------------------
     X selectors: server -> cache -> built-in (selector_sync.py)
  --------------------------------------------------------------- */
  const Selectors = (() => {
    const current = JSON.parse(JSON.stringify(CFG.defaultSelectors));
    let loading = null;

    function apply(groups) {
      if (!groups || typeof groups !== 'object') return;
      Object.keys(CFG.defaultSelectors).forEach((name) => {
        const value = groups[name];
        if (!Array.isArray(value)) return;
        const cleaned = value.filter((v) => typeof v === 'string' && v.trim()).map((v) => v.trim());
        if (cleaned.length) current[name] = cleaned;
      });
    }

    function load() {
      if (!loading) {
        loading = (async () => {
          apply(await store.get('selectorsCache'));
          try {
            const res = await fetch(`${API}/api/selectors`, { cache: 'no-store' });
            if (res.ok) {
              const data = await res.json();
              if (data && data.selectors) {
                apply(data.selectors);
                await store.set('selectorsCache', data.selectors);
              }
            }
          } catch (_) {
            // cached / built-in selectors stand
          }
        })();
      }
      return loading;
    }

    return { load, get: () => current };
  })();

  /* ---------------------------------------------------------------
     The X tab — one reusable worker tab (manager.py)
  --------------------------------------------------------------- */
  const Worker = (() => {
    const MAX_NAVIGATIONS = 40; // recycle the tab so a long run never bloats it
    let tabId = null;
    let windowId = null;
    let navigations = 0;
    let platform = null;
    let dashboard = null;
    let idleTimer = null;

    async function isAndroid() {
      if (platform === null) {
        try {
          platform = (await ext.runtime.getPlatformInfo()).os;
        } catch (_) {
          platform = /Android/i.test(navigator.userAgent) ? 'android' : '';
        }
      }
      return platform === 'android';
    }

    async function useWindows() {
      if (CFG.forceTabMode) return false;
      return !(await isAndroid()) && Boolean(ext.windows && ext.windows.create);
    }

    async function rememberDashboard() {
      if (dashboard) return;
      try {
        const tab = await ext.tabs.getCurrent();
        if (tab) dashboard = { tabId: tab.id, windowId: tab.windowId };
      } catch (_) {
        dashboard = null;
      }
    }

    async function alive() {
      if (tabId === null) return false;
      try {
        await ext.tabs.get(tabId);
        return true;
      } catch (_) {
        tabId = null;
        windowId = null;
        return false;
      }
    }

    function toWorkerUrl(url) {
      if (X_ORIGIN === 'https://x.com') return url;
      return url.replace(/^https?:\/\/(www\.|mobile\.)?(x|twitter)\.com/i, X_ORIGIN);
    }

    async function waitForStatus(id, predicate, timeoutMs) {
      const deadline = Date.now() + timeoutMs;
      while (Date.now() < deadline) {
        let tab;
        try {
          tab = await ext.tabs.get(id);
        } catch (_) {
          throw fail('navigation_failed', 'The X tab was closed while XPilot was using it.', 502);
        }
        if (predicate(tab)) return tab;
        await sleep(200);
      }
      throw fail('navigation_failed', 'X took too long to load. Check your internet connection, then try again.', 502);
    }

    // Navigation that cannot mistake the previous page's "complete" for the
    // new one: wait to see the tab start loading, then finish.
    async function navigateExisting(url) {
      let sawLoading = false;
      const onUpdated = (id, info) => {
        if (id === tabId && info.status === 'loading') sawLoading = true;
      };
      ext.tabs.onUpdated.addListener(onUpdated);
      try {
        await ext.tabs.update(tabId, { url });
        await waitForStatus(tabId, (tab) => sawLoading && tab.status === 'complete', CFG.navigationTimeoutMs);
      } finally {
        ext.tabs.onUpdated.removeListener(onUpdated);
      }
    }

    async function openFresh(url) {
      if (await useWindows()) {
        const win = await ext.windows.create({ url, focused: true, width: 1180, height: 900, type: 'normal' });
        windowId = win.id;
        tabId = win.tabs && win.tabs[0] ? win.tabs[0].id : (await ext.tabs.query({ windowId: win.id }))[0].id;
      } else {
        const tab = await ext.tabs.create({ url, active: true });
        tabId = tab.id;
        windowId = tab.windowId;
      }
      navigations = 1;
      await sleep(300);
      await waitForStatus(tabId, (tab) => tab.status === 'complete', CFG.navigationTimeoutMs);
    }

    async function bringToFront() {
      clearTimeout(idleTimer);
      try {
        await ext.tabs.update(tabId, { active: true });
        if (await useWindows()) await ext.windows.update(windowId, { focused: true });
      } catch (_) {
        // best-effort
      }
    }

    async function returnToDashboard() {
      if (!dashboard) return;
      try {
        await ext.tabs.update(dashboard.tabId, { active: true });
        if (await useWindows()) await ext.windows.update(dashboard.windowId, { focused: true });
      } catch (_) {
        // the XPilot tab may have been moved; nothing to do
      }
    }

    // After a run goes quiet, bring the XPilot tab back to the front.
    function settleBack() {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(returnToDashboard, CFG.returnFocusAfterMs);
    }

    async function waitForContentScript() {
      const deadline = Date.now() + 10000;
      while (Date.now() < deadline) {
        try {
          const res = await ext.tabs.sendMessage(tabId, { op: 'ping' });
          if (res && res.ok) return;
        } catch (_) {
          // not injected yet
        }
        await sleep(250);
      }
      throw fail(
        'browser_permission',
        "XPilot couldn't work in the X tab. Make sure XPilot is allowed to run on x.com (your browser's extension settings), then try again.",
        502
      );
    }

    async function navigate(url) {
      await rememberDashboard();
      const target = toWorkerUrl(url);
      if (await alive()) {
        await bringToFront();
        if (navigations >= MAX_NAVIGATIONS) {
          const old = tabId;
          tabId = null;
          await openFresh(target);
          try {
            await ext.tabs.remove(old);
          } catch (_) {
            // already gone
          }
        } else {
          navigations += 1;
          await navigateExisting(target);
        }
      } else {
        await openFresh(target);
      }
      await waitForContentScript();
    }

    async function run(op, args) {
      let res;
      try {
        res = await ext.tabs.sendMessage(tabId, { op, ...args });
      } catch (_) {
        throw fail('navigation_failed', 'The X tab stopped responding (it may have been closed or navigated away).', 502);
      }
      if (!res) throw fail('browser_error', 'No response from the X tab.', 502);
      if (!res.ok) throw fail(res.error.code, res.error.message, res.error.status || 502, res.error.details);
      return res.data;
    }

    return { navigate, run, settleBack, bringToFront };
  })();

  /* ---------------------------------------------------------------
     X session (cookies of the user's own browser)
  --------------------------------------------------------------- */
  async function cookie(name) {
    try {
      const c = await ext.cookies.get({ url: `${X_ORIGIN}/`, name });
      return c && c.value ? c.value : null;
    } catch (_) {
      return null;
    }
  }

  async function signedInToX() {
    return Boolean((await cookie('auth_token')) || (await cookie('twid')));
  }

  async function xUserId() {
    const twid = await cookie('twid');
    const match = /u=(\d+)/.exec(decodeURIComponent(twid || ''));
    return match ? match[1] : null;
  }

  function opArgs(extra) {
    return {
      ...extra,
      S: Selectors.get(),
      cfg: {
        actionMs: CFG.actionTimeoutMs,
        minArticleChars: CFG.minArticleChars,
        prePostPauseMs: CFG.prePostPauseMs,
        duplicatePhrases: CFG.duplicatePhrases,
        rateLimitPhrases: CFG.rateLimitPhrases,
      },
    };
  }

  async function showLoginPage() {
    try {
      await Worker.navigate(`${X_ORIGIN}/i/flow/login`);
    } catch (_) {
      // the user can still open x.com themselves
    }
  }

  /* ---------------------------------------------------------------
     AI context + generation (pilot_service.py + proxy_provider.py)
  --------------------------------------------------------------- */
  const MAX_CHARS = CFG.maxPostCharsForAi;
  const VALID_STYLES = ['professional', 'funny', 'educational', 'promotional'];

  function clipText(text, limit = MAX_CHARS) {
    const t = String(text || '').trim();
    if (t.length <= limit) return t;
    let clipped = t.slice(0, limit - 1);
    const cut = clipped.lastIndexOf(' ');
    if (cut > Math.floor(limit / 2)) clipped = clipped.slice(0, cut);
    return `${clipped.trimEnd()}…`;
  }

  function clipParagraphs(text, limit) {
    const t = String(text || '').trim();
    if (t.length <= limit) return t;
    const kept = [];
    let used = 0;
    for (const raw of t.split('\n')) {
      const paragraph = raw.trim();
      if (!paragraph) continue;
      if (used + paragraph.length + 1 > limit) break;
      kept.push(paragraph);
      used += paragraph.length + 1;
    }
    return kept.length ? `${kept.join('\n')}\n…` : clipText(t, limit);
  }

  function buildContext(text, kind, title, postText) {
    if (kind !== 'article') return clipText(text);
    const header = ['[This is a long-form X Article. Reply to its content.]'];
    if (title) header.push(`Article title: ${clipText(title, 300)}`);
    if (postText && postText.trim()) header.push(`Post sharing the article: ${clipText(postText, 400)}`);
    const prefix = `${header.join('\n')}\n\nArticle content:\n`;
    return prefix + clipParagraphs(text, Math.max(MAX_CHARS - prefix.length, 500));
  }

  async function serverMessage(res, fallback) {
    try {
      const body = await res.json();
      if (body && body.message) return String(body.message);
    } catch (_) {
      // not JSON
    }
    return fallback;
  }

  async function proxyGenerate(text, style) {
    const key = License.keyFull();
    if (!key) {
      throw fail('ai_provider_not_configured', 'XPilot is not activated, so replies cannot be generated. Activate your license and try again.', 503);
    }
    const payload = { license_key: key, hardware_id: await installId(), text, style };
    const xid = await xUserId();
    if (xid) payload.x_user_id = xid;

    const attempts = CFG.aiMaxRetries + 1;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), CFG.aiTimeoutMs);
      let res;
      try {
        res = await fetch(`${API}/api/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });
      } catch (err) {
        clearTimeout(timer);
        if (err && err.name === 'AbortError') {
          throw fail('generation_timeout', `The AI service did not respond within ${CFG.aiTimeoutMs / 1000}s.`, 504);
        }
        if (attempt < attempts) {
          await sleep(CFG.aiBackoffMs * attempt);
          continue;
        }
        throw fail('ai_provider_unavailable', 'The AI service is unreachable. Check your internet connection.', 503);
      }
      clearTimeout(timer);

      if (res.status === 401 || res.status === 403) {
        throw fail('generation_failed', await serverMessage(res, 'The AI service rejected your license. Reactivate XPilot and try again.'), 502);
      }
      if (res.status === 404) throw fail('generation_failed', 'The AI endpoint was not found on the server (HTTP 404).', 502);
      if (res.status === 429 && attempt < attempts) {
        await sleep(CFG.aiBackoffMs * attempt);
        continue;
      }
      if (!res.ok) throw fail('generation_failed', await serverMessage(res, `The AI service returned HTTP ${res.status}.`), 502);

      let data;
      try {
        data = await res.json();
      } catch (_) {
        throw fail('generation_failed', 'The AI service returned a non-JSON response.', 502);
      }
      const reply = String((data && data.reply) || '').trim();
      if (!reply) throw fail('generation_failed', 'The AI service returned an empty reply.', 502);
      const total = data.usage && data.usage.total_tokens;
      return { reply, tokens: typeof total === 'number' && total > 0 ? Math.round(total) : null };
    }
    throw fail('ai_provider_unavailable', 'The AI service is unreachable. Check your internet connection.', 503);
  }

  /* ---------------------------------------------------------------
     Product operations
  --------------------------------------------------------------- */
  async function checkLogin(body) {
    const navigate = body && 'navigate' in body ? Boolean(body.navigate) : true;
    if (await signedInToX()) return { logged_in: true };
    if (navigate) await showLoginPage();
    return { logged_in: false };
  }

  async function readPost(body) {
    const url = validateReadableUrl(requireString(body, 'url', 2048));
    await Selectors.load();
    try {
      const loggedIn = await signedInToX();
      let result;
      if (isArticleUrl(url)) {
        await Worker.navigate(url);
        result = await Worker.run('readArticle', opArgs({ url, replyUrl: null, postText: null, loggedIn }));
      } else {
        await Worker.navigate(url);
        result = await Worker.run('read', opArgs({ url, loggedIn }));
        if (result.needsArticle) {
          const postText = result.post_text;
          await Worker.navigate(result.needsArticle);
          result = await Worker.run('readArticle', opArgs({ url: result.needsArticle, replyUrl: url, postText, loggedIn }));
        }
      }
      return {
        url: result.url || url,
        text: result.text,
        author: result.author || null,
        kind: result.kind || 'post',
        title: result.title || null,
        reply_url: result.reply_url || null,
        post_text: result.post_text || null,
        chars: (result.text || '').length,
      };
    } catch (err) {
      await Usage.record({ ok: false, kind: isArticleUrl(url) ? 'article' : 'post' });
      if (err.code === 'not_logged_in') await showLoginPage();
      throw err;
    } finally {
      Worker.settleBack();
    }
  }

  async function generateFromText(body) {
    const text = requireString(body, 'text', 200000);
    let style = body && typeof body.style === 'string' ? body.style : 'professional';
    style = style.trim().toLowerCase();
    if (!VALID_STYLES.includes(style)) {
      throw fail('validation_error', `Unknown reply style '${body.style}'.`, 400, { valid_styles: VALID_STYLES });
    }
    const kind = body.kind === undefined || body.kind === null ? 'post' : body.kind;
    if (!['post', 'article'].includes(kind)) throw fail('validation_error', "Field 'kind' must be one of post, article.");
    const optional = (field, max) => (typeof body[field] === 'string' && body[field].trim() ? body[field].trim().slice(0, max) : null);

    const context = buildContext(text, kind, optional('title', 500), optional('post_text', 5000));
    let result;
    try {
      result = await proxyGenerate(context, style);
    } catch (err) {
      await Usage.record({ ok: false, kind });
      throw err;
    }
    const estimated = result.tokens === null;
    const tokens = estimated ? Math.max(1, Math.ceil((1200 + context.length + result.reply.length) / 4)) : result.tokens;
    await Usage.record({ ok: true, kind, tokens, estimated });
    return { reply: result.reply, style, kind, tokens };
  }

  let lastPostAt = 0;
  async function pace() {
    if (!lastPostAt) return;
    const low = CFG.minSecondsBetweenPosts;
    const high = Math.max(CFG.maxSecondsBetweenPosts, low);
    if (high <= 0) return;
    const target = (low + Math.random() * (high - low)) * 1000;
    const remaining = target - (Date.now() - lastPostAt);
    if (remaining > 0) await sleep(remaining);
  }

  async function postReply(body) {
    const url = validatePostUrl(requireString(body, 'url', 2048));
    const reply = requireString(body, 'reply', 4000);
    const like = Boolean(body.like);
    const verifyTexts = [];
    if (body.verify_existing) {
      verifyTexts.push(reply);
      const previous = body.previous_replies || [];
      if (!Array.isArray(previous)) throw fail('validation_error', "Field 'previous_replies' must be a list of strings.");
      previous
        .slice(0, 10)
        .filter((t) => typeof t === 'string' && t.trim())
        .forEach((t) => verifyTexts.push(t.trim().slice(0, 4000)));
    }
    await Selectors.load();
    await pace();
    try {
      const loggedIn = await signedInToX();
      await Worker.navigate(url);
      const result = await Worker.run('post', opArgs({ url, text: reply, like, verifyTexts, loggedIn }));
      return { posted: true, liked: Boolean(result.liked), already_posted: Boolean(result.already_posted), url };
    } catch (err) {
      if (err.code === 'not_logged_in') await showLoginPage();
      throw err;
    } finally {
      lastPostAt = Date.now(); // a refused attempt still counts towards X's pacing
      Worker.settleBack();
    }
  }

  async function openExternal(body) {
    const url = requireString(body, 'url', 2048);
    let parsed;
    try {
      parsed = new URL(url);
    } catch (_) {
      throw fail('validation_error', 'That link is not a valid URL.');
    }
    if (!['http:', 'https:'].includes(parsed.protocol) || !EXTERNAL_HOSTS.has(parsed.hostname.toLowerCase())) {
      throw fail('validation_error', 'Only x.com and twitter.com links can be opened from XPilot.', 400, { url });
    }
    await ext.tabs.create({ url, active: true });
    return { opened: true, url };
  }

  /* ---------------------------------------------------------------
     Router — same paths, methods and gate as the app's Flask API
  --------------------------------------------------------------- */
  const EXEMPT = ['/license', '/health', '/config', '/ai/health', '/preferences'];

  async function request(path, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    const [route, query = ''] = path.split('?');
    let body = {};
    if (options.body) {
      try {
        body = JSON.parse(options.body);
      } catch (_) {
        throw fail('validation_error', 'Request body must be a JSON object.');
      }
    }

    await License.whenReady();
    const exempt = EXEMPT.some((p) => route === p || route.startsWith(`${p}/`));
    if (!exempt && !License.isActivated()) {
      throw fail('license_required', 'XPilot is not activated. Enter a valid license key to continue.', 403);
    }

    const key = `${method} ${route}`;
    switch (key) {
      case 'GET /license/status':
        return License.status();
      case 'GET /license/usage':
        return License.refreshUsage();
      case 'POST /license/activate':
        return License.activate(requireString(body, 'license_key', 256));
      case 'POST /license/logout':
        return License.logout();
      case 'GET /preferences':
        return Prefs.get();
      case 'PUT /preferences':
        return Prefs.put(body);
      case 'GET /usage/summary': {
        const days = Number(new URLSearchParams(query).get('days') || 7);
        if (!Number.isInteger(days)) throw fail('validation_error', "'days' must be 7, 30 or 90.");
        return Usage.summary(days);
      }
      case 'POST /browser/check-login':
        return checkLogin(body);
      case 'POST /read-post':
        return readPost(body);
      case 'POST /generate-from-text':
        return generateFromText(body);
      case 'POST /post-reply':
        return postReply(body);
      case 'POST /open-external':
        return openExternal(body);
      default:
        throw fail('not_found', `Unknown endpoint ${key}.`, 404);
    }
  }

  window.XPilotBridge = { request };

  /* ---------------------------------------------------------------
     Firefox: host access is granted by the user, not at install
  --------------------------------------------------------------- */
  async function ensureHostAccess() {
    if (!ext.permissions || !ext.permissions.contains) return;
    let granted = true;
    try {
      granted = await ext.permissions.contains({ origins: CFG.hostPermissions });
    } catch (_) {
      granted = true;
    }
    if (granted) return;

    const overlay = document.createElement('div');
    overlay.className = 'license-gate';
    overlay.style.zIndex = '9600';
    overlay.innerHTML = `
      <div class="license-gate-card">
        <svg class="license-gate-logo" aria-hidden="true"><use href="#i-x-logo"/></svg>
        <h1 class="license-gate-title">Allow XPilot on X</h1>
        <p class="license-gate-sub">XPilot needs your permission to work on x.com and to reach the XPilot server. It only acts in the tab it opens for you.</p>
        <button type="button" class="btn btn-solid license-gate-btn">Allow access</button>
        <p class="license-gate-hint"></p>
      </div>`;
    document.body.appendChild(overlay);
    const hint = overlay.querySelector('.license-gate-hint');
    overlay.querySelector('button').addEventListener('click', async () => {
      let ok = false;
      try {
        ok = await ext.permissions.request({ origins: CFG.hostPermissions });
      } catch (_) {
        ok = false;
      }
      if (ok) overlay.remove();
      else hint.textContent = 'XPilot cannot work without this permission. Click Allow access and choose Allow.';
    });
  }

  document.addEventListener('DOMContentLoaded', ensureHostAccess);
})();
