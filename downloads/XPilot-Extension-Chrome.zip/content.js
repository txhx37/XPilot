/**
 * XPilot extension — content script (runs inside x.com tabs).
 * ------------------------------------------------------------------
 * The browser-side twin of the desktop app's backend/xpilot/browser/
 * reader.py and poster.py. It only acts when the XPilot page asks it to
 * (a message with an `op`); otherwise it does nothing on the page.
 *
 * Selectors, phrases and timings are sent with every request, so this file
 * holds procedure only — an X layout change is fixed in the selector data
 * (server-overridable), exactly as in the app.
 * ------------------------------------------------------------------ */
(() => {
  'use strict';

  if (window.__xpilotContentLoaded) return;
  window.__xpilotContentLoaded = true;

  const ext = globalThis.browser || globalThis.chrome;
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  class OpError extends Error {
    constructor(code, message, status = 502, details = null) {
      super(message);
      this.code = code;
      this.status = status;
      this.details = details;
    }
  }

  /* ---------------------------------------------------------------
     DOM helpers
  --------------------------------------------------------------- */
  function qa(selector, root = document) {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch (_) {
      return []; // a malformed server-pushed selector must never crash an op
    }
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden';
  }

  function firstVisible(candidates, root = document) {
    for (const selector of candidates) {
      for (const el of qa(selector, root)) {
        if (isVisible(el)) return el;
      }
    }
    return null;
  }

  async function waitFor(fn, timeoutMs, intervalMs = 200) {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const value = fn();
      if (value) return value;
      if (Date.now() >= deadline) return null;
      await sleep(intervalMs);
    }
  }

  function textOf(root, candidates) {
    for (const selector of candidates) {
      const el = qa(selector, root)[0];
      if (!el) continue;
      const value = (el.innerText || el.textContent || '').trim();
      if (value) return value;
    }
    return null;
  }

  function firstText(candidates) {
    const value = textOf(document, candidates);
    return value ? value.split(/\s+/).join(' ') : null;
  }

  function normalizeBlockText(text) {
    const out = [];
    String(text || '')
      .split(/\r?\n/)
      .map((line) => line.trim())
      .forEach((line) => {
        if (!line && (!out.length || !out[out.length - 1])) return;
        out.push(line);
      });
    return out.join('\n').trim();
  }

  const STATUS_ID_RE = /\/status\/(\d+)/;
  const ARTICLE_PATH_RE = /^\/(?:i|[A-Za-z0-9_]{1,15})\/article\/\d+/i;

  function statusIdOf(url) {
    const match = STATUS_ID_RE.exec(url);
    return match ? match[1] : null;
  }

  function absoluteXUrl(href) {
    try {
      return `https://x.com${new URL(href, 'https://x.com').pathname}`;
    } catch (_) {
      return null;
    }
  }

  function isArticlePath(href) {
    try {
      return ARTICLE_PATH_RE.test(new URL(href, 'https://x.com').pathname);
    } catch (_) {
      return false;
    }
  }

  /* ---------------------------------------------------------------
     Shared reading primitives (reader.py)
  --------------------------------------------------------------- */
  // The article for the post the URL names — not whatever is on top. On a
  // link to a reply X renders the parent chain above it, so the first
  // article belongs to a different post.
  async function targetArticle(url, S, timeoutMs) {
    const id = statusIdOf(url);
    if (id) {
      const ownLink = new RegExp(`/status/${id}(?:[/?#]|$)`);
      const pinned = await waitFor(() => {
        for (const base of S.TWEET_ARTICLE) {
          for (const article of qa(base)) {
            const mine = qa('a[href*="/status/"]', article).some((a) => ownLink.test(a.getAttribute('href') || ''));
            if (mine && isVisible(article)) return article;
          }
        }
        return null;
      }, Math.max(timeoutMs / 2, 2000));
      if (pinned) return pinned;
    }
    return waitFor(() => firstVisible(S.TWEET_ARTICLE), id ? Math.max(timeoutMs / 2, 1500) : timeoutMs);
  }

  function isLoggedInDom(S) {
    if (firstVisible(S.LOGGED_OUT_MARKERS)) return false;
    if (firstVisible(S.LOGGED_OUT_ARTICLE)) return false;
    return Boolean(firstVisible(S.LOGGED_IN_MARKERS));
  }

  async function signedIn(S, hint) {
    if (typeof hint === 'boolean') return hint; // cookie check from the XPilot page
    return Boolean(await waitFor(() => isLoggedInDom(S) || null, 4000));
  }

  function notLoggedIn() {
    return new OpError(
      'not_logged_in',
      "You're not signed in to X in this browser. The X login page is open in the XPilot tab — sign in there, then click Generate again.",
      409
    );
  }

  function withinVisible(root, candidates) {
    for (const selector of candidates) {
      const el = qa(selector, root)[0];
      if (el && isVisible(el)) return el;
    }
    return null;
  }

  // Inner text once it stops growing (articles stream in block by block).
  async function settledText(el, budgetMs = 6000) {
    const deadline = Date.now() + budgetMs;
    let previous = -1;
    let text = '';
    while (Date.now() < deadline) {
      text = (el.innerText || el.textContent || '').trim();
      if (text && text.length === previous) break;
      previous = text.length;
      await sleep(500);
    }
    return normalizeBlockText(text);
  }

  function restrictionNotice(phrases) {
    for (const el of qa('span, div, h1, h2')) {
      if (el.childElementCount !== 0) continue;
      const s = (el.textContent || '').trim();
      if (s.length < 8 || s.length > 300) continue;
      const low = s.toLowerCase();
      if (phrases.some((p) => low.includes(p.toLowerCase()))) return s;
    }
    return null;
  }

  function articleLinkIn(article, S) {
    for (const selector of S.ARTICLE_LINK) {
      for (const a of qa(selector, article).slice(0, 5)) {
        const href = a.getAttribute('href') || '';
        if (isArticlePath(href)) return absoluteXUrl(href);
      }
    }
    return null;
  }

  // The post that shares the article: the author header's timestamp link.
  function sharingPostUrl() {
    const ok = /^\/[A-Za-z0-9_]{1,15}\/status\/\d+\/?$/;
    for (const a of qa('a[href*="/status/"]')) {
      const href = a.getAttribute('href') || '';
      if (ok.test(href) && a.querySelector('time')) return absoluteXUrl(href.replace(/\/$/, ''));
    }
    return null;
  }

  /* ---------------------------------------------------------------
     Has this account already commented on the post? (reader.has_own_reply)
     Only posts BELOW the target count; X's "Discover more" section of
     unrelated posts is ignored. Any doubt answers false, so a link is
     never wrongly skipped.
  --------------------------------------------------------------- */
  function ownReplyState(statusId) {
    const profile = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    const handle = profile
      ? (profile.getAttribute('href') || '').replace(/^\//, '').split(/[/?#]/)[0].toLowerCase()
      : '';
    const result = { handle, found: false, replies: 0 };
    if (!handle || !statusId) return result;
    const arts = qa('article[data-testid="tweet"], article[role="article"]');
    const ownLink = new RegExp(`/status/${statusId}(?:[/?#]|$)`);
    const target = arts.find((a) => qa('a[href*="/status/"]', a).some((l) => ownLink.test(l.getAttribute('href') || '')));
    if (!target) return result;
    const after = (a, b) => Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
    let stop = null;
    for (const h of qa('h2, [role="heading"]')) {
      const t = (h.textContent || '').trim().toLowerCase();
      if ((t === 'discover more' || t.startsWith('more posts')) && after(target, h)) {
        stop = h;
        break;
      }
    }
    const mention = new RegExp(`@${handle.replace(/[^a-z0-9_]/g, '')}(?![a-z0-9_])`, 'i');
    for (const a of arts) {
      if (a === target || target.contains(a) || a.contains(target)) continue;
      if (!after(target, a)) continue;
      if (stop && after(stop, a)) continue;
      result.replies += 1;
      const name = a.querySelector('[data-testid="User-Name"]');
      if (name && mention.test(name.textContent || '')) {
        result.found = true;
        break;
      }
    }
    return result;
  }

  async function hasOwnReply(url, waitMs) {
    const id = statusIdOf(url);
    if (!id) return false;
    let scrolled = false;
    try {
      const deadline = Date.now() + Math.max(waitMs || 0, 0);
      let state;
      for (;;) {
        state = ownReplyState(id);
        if (state.found) return true;
        if ((state.handle && state.replies) || Date.now() >= deadline) break;
        await sleep(300);
      }
      if (!state.handle || !state.replies) return false;
      for (let step = 0; step < 2; step += 1) {
        window.scrollBy(0, window.innerHeight * 0.9);
        scrolled = true;
        await sleep(700);
        if (ownReplyState(id).found) return true;
      }
      return false;
    } catch (_) {
      return false;
    } finally {
      if (scrolled) window.scrollTo(0, 0);
    }
  }

  /* ---------------------------------------------------------------
     op: read — a post page
  --------------------------------------------------------------- */
  async function opRead({ url, S, cfg, loggedIn }) {
    const article = await targetArticle(url, S, cfg.actionMs);
    if (!article) {
      if (await waitFor(() => firstVisible(S.POST_UNAVAILABLE), 2000)) {
        throw new OpError('post_not_found', 'This post is unavailable (deleted, protected, or restricted).', 404, { url });
      }
      if (!(await signedIn(S, loggedIn))) throw notLoggedIn();
      throw new OpError(
        'post_not_found',
        'Could not locate the post on the page — X may have changed its layout, or the post did not finish loading.',
        404,
        { url }
      );
    }

    // Already commented on this post from this account? Skip it entirely:
    // nothing is extracted, generated, posted or liked.
    if (await hasOwnReply(url, cfg.ownReplyWaitMs)) {
      return { url, text: '', author: null, kind: 'post', title: null, reply_url: url, post_text: null, already_replied: true };
    }

    const text = textOf(article, S.TWEET_TEXT);
    const author = textOf(article, S.TWEET_AUTHOR);

    // A post that shares an X Article: reply to the article's content.
    const inline = withinVisible(article, S.ARTICLE_BODY);
    if (inline) {
      const body = await settledText(inline);
      if (body.length >= cfg.minArticleChars) {
        return {
          url,
          text: body,
          author,
          kind: 'article',
          title: textOf(article, S.ARTICLE_TITLE),
          reply_url: url,
          post_text: text && !body.includes(text) ? text : null,
        };
      }
    }
    const articleHref = articleLinkIn(article, S);
    if (articleHref) return { needsArticle: articleHref, post_text: text || null };

    if (!text) {
      throw new OpError('post_not_found', 'The post was found but its text could not be extracted (it may be media-only).', 404, { url });
    }
    return { url, text, author, kind: 'post', title: null, reply_url: url, post_text: null };
  }

  /* ---------------------------------------------------------------
     op: readArticle — an /i/article/<id> page
  --------------------------------------------------------------- */
  async function opReadArticle({ url, replyUrl, postText, S, cfg, loggedIn }) {
    const bodyEl = await waitFor(() => firstVisible(S.ARTICLE_BODY), cfg.actionMs);
    if (!bodyEl) {
      if (await waitFor(() => firstVisible(S.POST_UNAVAILABLE), 2000)) {
        throw new OpError('article_unavailable', 'This X Article is unavailable — it may have been deleted, or the link is wrong.', 404, { url });
      }
      const restriction = restrictionNotice(S.ARTICLE_RESTRICTED_PHRASES);
      if (restriction) {
        throw new OpError(
          'article_restricted',
          `This X Article is private or restricted, so XPilot cannot read it. X says: “${restriction}”`,
          403,
          { url, x_message: restriction }
        );
      }
      if (!(await signedIn(S, loggedIn))) throw notLoggedIn();
      throw new OpError(
        'article_unavailable',
        'The X Article did not load, so its content could not be read. X may have changed its article layout, or the article had not finished loading — try again in a moment.',
        404,
        { url }
      );
    }

    const body = await settledText(bodyEl);
    const title = firstText(S.ARTICLE_TITLE);
    const author = firstText(S.TWEET_AUTHOR);
    const reply = replyUrl || sharingPostUrl();

    if (body.length < cfg.minArticleChars) {
      const restriction = restrictionNotice(S.ARTICLE_RESTRICTED_PHRASES);
      if (restriction) {
        throw new OpError(
          'article_restricted',
          `This X Article is restricted, so XPilot cannot read it. X says: “${restriction}”`,
          403,
          { url, x_message: restriction }
        );
      }
      throw new OpError(
        'article_incomplete',
        `Only part of this X Article could be read (${body.length} characters), which is not enough to write a reply that responds to it. Open the article in the XPilot tab to check it loads fully, then try again.`,
        422,
        { url, chars: body.length }
      );
    }
    return { url, text: body, author, kind: 'article', title, reply_url: reply, post_text: postText || null };
  }

  /* ---------------------------------------------------------------
     Posting primitives (poster.py)
  --------------------------------------------------------------- */
  function within(article, candidates) {
    for (const selector of candidates) {
      const el = qa(selector, article)[0];
      if (el && isVisible(el)) return el;
    }
    return null;
  }

  function readToast(S) {
    for (const selector of S.TOAST) {
      const el = qa(selector)[0];
      if (el && isVisible(el)) {
        const text = (el.innerText || el.textContent || '').trim();
        if (text) return text.split(/\s+/).join(' ');
      }
    }
    return '';
  }

  function raiseForToast(toast, url, cfg) {
    const lowered = toast.toLowerCase();
    if (cfg.duplicatePhrases.some((p) => lowered.includes(p))) {
      throw new OpError(
        'duplicate_reply',
        `X rejected this reply as a duplicate of one already sent. X said: “${toast}”`,
        409,
        { url, x_message: toast }
      );
    }
    if (cfg.rateLimitPhrases.some((p) => lowered.includes(p))) {
      throw new OpError(
        'reply_rate_limited',
        `X is currently limiting replies from this account, so the reply was not posted. X said: “${toast}” Pause posting for a few hours and slow the pace before resuming.`,
        429,
        { url, x_message: toast }
      );
    }
  }

  async function likeOnPage(article, S, cfg) {
    if (within(article, S.UNLIKE_BUTTON)) return true; // already liked — never un-like
    const button = within(article, S.LIKE_BUTTON);
    if (!button) return false;
    button.click();
    return Boolean(await waitFor(() => within(article, S.UNLIKE_BUTTON), cfg.actionMs / 2, 250));
  }

  function dismissPopupComposer() {
    const dialogs = qa('[role="dialog"]');
    if (!dialogs.length) return;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
  }

  // Wait (briefly) for the page to stop moving: two equal samples.
  async function settle(budgetMs = 3000) {
    const deadline = Date.now() + budgetMs;
    let previous = null;
    while (Date.now() < deadline) {
      const current = `${Math.round(window.scrollY)}:${Math.round(document.body.scrollHeight)}`;
      if (current === previous) return;
      previous = current;
      await sleep(250);
    }
  }

  // One read describing what the page offers (poster._composer_state).
  function composerState(S) {
    const usable = (el) => {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' && el.getAttribute('aria-disabled') !== 'true';
    };
    const firstUsable = (sels) => {
      for (const s of sels) for (const el of qa(s)) if (usable(el)) return s;
      return null;
    };
    const BLOCKED = /can(?:'|’)?t reply|cannot reply|(?:not|un)able to reply|not allowed to reply/i;
    const LIMITED = /can reply|who can reply|replies (?:are )?limited|limited who can reply/i;
    let restricted = null;
    let limitedNotice = null;
    for (const el of qa('main span, main div')) {
      if (el.childElementCount !== 0) continue;
      if (el.closest('[data-testid="tweetText"]')) continue;
      const s = (el.textContent || '').trim();
      if (s.length <= 12 || s.length >= 200) continue;
      if (BLOCKED.test(s)) {
        restricted = s;
        break;
      }
      if (!limitedNotice && LIMITED.test(s)) limitedNotice = s;
    }
    let accountRestricted = null;
    for (const el of qa('span, div')) {
      if (el.childElementCount !== 0) continue;
      if (el.closest('article')) continue;
      const s = (el.textContent || '').trim();
      if (s.length < 12 || s.length > 300) continue;
      const low = s.toLowerCase();
      if (S.ACCOUNT_RESTRICTED_PHRASES.some((p) => low.includes(p.toLowerCase()))) {
        accountRestricted = s;
        break;
      }
    }
    return {
      textbox: firstUsable(S.INLINE_REPLY_TEXTBOX),
      replyButton: firstUsable(S.REPLY_BUTTON),
      restricted,
      limitedNotice,
      accountRestricted,
      articles: qa('article[data-testid="tweet"], article[role="article"]').length,
    };
  }

  function describeComposerFailure(state) {
    if (state.restricted) return `X does not allow replying to this post (${state.restricted}).`;
    if (state.limitedNotice) {
      return `This post limits who can reply, and X shows no reply box to this account, so it is not eligible to reply here (X says: “${state.limitedNotice}”).`;
    }
    if (!state.articles) return 'The post never finished loading, so the reply box beneath it never appeared.';
    if (state.replyButton) {
      return 'The reply box beneath this post never became usable, even though the post has a Reply button — X may not be accepting replies to it from this account.';
    }
    return 'No reply box appeared beneath this post.';
  }

  // The inline reply box beneath the post (preferred). On layouts that have
  // none — X's narrow/mobile layout — the post's Reply button opens X's own
  // composer, which is then the only composer on the page.
  async function openComposer(article, S, url) {
    const deadline = Date.now() + 20000;
    let barren = 0;
    let refusals = 0;
    let state = {};
    while (Date.now() < deadline) {
      state = composerState(S);
      if (state.textbox) {
        const box = firstVisible(S.INLINE_REPLY_TEXTBOX);
        if (box) return { textbox: box, mode: 'inline' };
      }
      if (state.accountRestricted) {
        throw new OpError(
          'account_restricted',
          `X has restricted this account, so no reply can be posted. X says: “${state.accountRestricted}” Posting will keep failing on every post until the account is back in good standing.`,
          502,
          { url, x_message: state.accountRestricted }
        );
      }
      if (state.restricted && state.articles) {
        refusals += 1;
        if (refusals >= 2) {
          throw new OpError('reply_not_allowed', `X does not allow this account to reply to this post (${state.restricted}).`, 403, {
            url,
            reason: state.restricted,
          });
        }
      } else {
        refusals = 0;
      }
      if (state.articles) {
        barren += 1;
        const limited = Boolean(state.limitedNotice);
        if (limited && barren === 3) {
          const r = article.getBoundingClientRect();
          window.scrollBy(0, r.bottom - window.innerHeight / 2);
        }
        if (barren >= 8 * (limited ? 2 : 1)) break;
      }
      await sleep(400);
    }

    // Narrow layouts: open X's own composer from the post's Reply button.
    if (!state.restricted && !state.accountRestricted) {
      const replyBtn = within(article, S.REPLY_BUTTON);
      if (replyBtn) {
        replyBtn.click();
        const box = await waitFor(() => firstVisible(S.REPLY_TEXTBOX), 8000);
        if (box) return { textbox: box, mode: 'composer' };
      }
    }

    const notAllowed = state.restricted || state.limitedNotice;
    throw new OpError(notAllowed ? 'reply_not_allowed' : 'post_reply_failed', describeComposerFailure(state), notAllowed ? 403 : 502, {
      url,
      page_state: state,
    });
  }

  function composerText(textbox) {
    return (textbox.innerText || textbox.textContent || '').replace(/\s+/g, ' ').trim();
  }

  // Type the reply through the browser's editing pipeline, which X's editor
  // treats like real typing; fall back to a paste event.
  async function enterText(textbox, text) {
    const target = text.replace(/\s+/g, ' ').trim();
    textbox.scrollIntoView({ block: 'center', inline: 'nearest' });
    textbox.focus();
    textbox.click();
    await sleep(200);
    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
    } catch (_) {
      // fall through to the paste path
    }
    if (await waitFor(() => composerText(textbox) === target, 1500, 100)) return;

    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      textbox.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch (_) {
      // reported below
    }
    if (!(await waitFor(() => composerText(textbox) === target, 1500, 100))) {
      throw new OpError('post_reply_failed', 'Could not enter the reply text into X’s reply box.', 502);
    }
  }

  function submitButtonFor(mode, S) {
    if (mode === 'inline') return firstVisible(S.INLINE_SUBMIT_BUTTON);
    const dialog = qa('[role="dialog"]').find(isVisible);
    return firstVisible(S.SUBMIT_BUTTON, dialog || document);
  }

  async function awaitSubmitEnabled(submit, text, url) {
    const ok = await waitFor(() => submit.getAttribute('aria-disabled') !== 'true', 10000, 250);
    if (ok) return;
    const length = text.length;
    if (length > 280) {
      throw new OpError(
        'post_reply_failed',
        `X will not accept this reply: it is ${length} characters and X's limit is 280 for a standard account. Shorten the reply and post it again.`,
        502,
        { url, reply_length: length, limit: 280 }
      );
    }
    throw new OpError(
      'post_reply_failed',
      'X kept the Reply button greyed out for this post, so the reply could not be sent. The post may limit who can reply, or the account may be restricted — open x.com to check for a notice from X.',
      502,
      { url, reply_length: length }
    );
  }

  function composerIsEmpty(mode, S) {
    const selectors = mode === 'inline' ? S.INLINE_REPLY_TEXTBOX : S.REPLY_TEXTBOX;
    return selectors.every((sel) => {
      const el = qa(sel)[0];
      return !el || !el.offsetParent || !(el.innerText || '').trim();
    });
  }

  async function confirmSubmitted(mode, S, url, cfg) {
    const deadline = Date.now() + cfg.actionMs;
    let lastToast = '';
    while (Date.now() < deadline) {
      if (composerIsEmpty(mode, S)) return;
      const toast = readToast(S);
      if (toast) {
        lastToast = toast;
        raiseForToast(toast, url, cfg);
      }
      await sleep(250);
    }
    if (composerIsEmpty(mode, S)) return;
    if (lastToast) {
      throw new OpError('post_reply_failed', `X did not accept the reply: ${lastToast}`, 502, { url, x_message: lastToast });
    }
    throw new OpError(
      'post_reply_failed',
      'X did not accept the reply (the composer still holds the text). This usually means the account is being throttled by X, or the reply breaks a length or content rule.',
      502,
      { url }
    );
  }

  // Retries only: is this account's reply (any of `texts`) already here?
  async function replyAlreadyOnPage(texts) {
    const norm = (s) =>
      (s || '')
        .toLowerCase()
        .replace(/[‘’]/g, "'")
        .replace(/[“”]/g, '"')
        .replace(/\s+/g, ' ')
        .trim();
    const targets = new Set(texts.map(norm).filter(Boolean));
    if (!targets.size) return false;
    const profile = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    const handle = profile ? (profile.getAttribute('href') || '').replace(/^\//, '').toLowerCase() : '';
    const found = () => {
      for (const art of qa('article[data-testid="tweet"], article[role="article"]')) {
        const textEl = art.querySelector('[data-testid="tweetText"]');
        if (!textEl || !targets.has(norm(textEl.innerText))) continue;
        if (!handle) return true;
        const name = art.querySelector('[data-testid="User-Name"]');
        if (name && norm(name.innerText).includes(`@${handle}`)) return true;
      }
      return false;
    };
    try {
      for (let step = 0; step < 4; step += 1) {
        if (found()) return true;
        if (step < 3) {
          window.scrollBy(0, window.innerHeight * 0.9);
          await sleep(700);
        }
      }
      return false;
    } finally {
      window.scrollTo(0, 0);
    }
  }

  /* ---------------------------------------------------------------
     op: post
  --------------------------------------------------------------- */
  async function opPost({ url, text, like, verifyTexts, S, cfg, loggedIn }) {
    const article = await targetArticle(url, S, cfg.actionMs);
    if (!article) {
      if (!(await signedIn(S, loggedIn))) throw notLoggedIn();
      throw new OpError('post_not_found', 'The post to reply to could not be found on the page.', 404, { url });
    }

    if (verifyTexts && verifyTexts.length && (await replyAlreadyOnPage(verifyTexts))) {
      const liked = like ? await likeOnPage(article, S, cfg) : false;
      return { liked, already_posted: true };
    }

    // Any earlier comment from this account on the post means: skip — no
    // reply, no like.
    if (await hasOwnReply(url, cfg.ownReplyWaitMs)) {
      return { liked: false, already_posted: true, already_replied: true };
    }

    const liked = like ? await likeOnPage(article, S, cfg) : false;
    dismissPopupComposer();
    const { textbox, mode } = await openComposer(article, S, url);
    await settle();
    await enterText(textbox, text);

    const submit = submitButtonFor(mode, S);
    if (!submit) {
      throw new OpError('post_reply_failed', 'The Reply button was not found — X may have changed its layout.', 502, { url });
    }
    // Pause before pressing Reply, like a person would.
    await sleep(cfg.prePostPauseMs);
    await awaitSubmitEnabled(submit, text, url);
    await settle();
    submit.click();
    await confirmSubmitted(mode, S, url, cfg);
    return { liked, already_posted: false };
  }

  /* ---------------------------------------------------------------
     Message plumbing
  --------------------------------------------------------------- */
  const OPS = {
    ping: async () => ({ ready: true, href: location.href }),
    read: opRead,
    readArticle: opReadArticle,
    post: opPost,
    loggedIn: async ({ S }) => ({ logged_in: isLoggedInDom(S) }),
  };

  ext.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    const handler = msg && OPS[msg.op];
    if (!handler) return false;
    Promise.resolve()
      .then(() => handler(msg))
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: {
            code: err.code || 'browser_error',
            message: err.message || 'Something went wrong in the X tab.',
            status: err.status || 502,
            details: err.details || null,
          },
        })
      );
    return true; // async response
  });
})();
