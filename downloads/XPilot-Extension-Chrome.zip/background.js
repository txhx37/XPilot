/**
 * XPilot extension — background.
 * Opens the XPilot page (the app's interface) when the toolbar button is
 * clicked or the extension is first installed, reusing an open one.
 */
const ext = globalThis.browser || globalThis.chrome;
const PAGE = 'app/index.html';
let pageTabId = null;

async function openXPilot() {
  if (pageTabId !== null) {
    try {
      const tab = await ext.tabs.update(pageTabId, { active: true });
      if (ext.windows && ext.windows.update && tab.windowId !== undefined) {
        await ext.windows.update(tab.windowId, { focused: true });
      }
      return;
    } catch (_) {
      pageTabId = null; // it was closed
    }
  }
  const tab = await ext.tabs.create({ url: ext.runtime.getURL(PAGE), active: true });
  pageTabId = tab.id;
}

ext.action.onClicked.addListener(() => {
  openXPilot();
});

ext.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') openXPilot();
});
